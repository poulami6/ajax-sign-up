<?php
/** 
 *Include all required files here
 */ 

//require get_parent_theme_file_path( '/classes/class-users.php' );


/**
 * Register a custom menu page.
 */
function __string_crypt( $string, $action = 'e' ) {
    // you may change these values to your own
    $secret_key = 'my_simple_secret_key';
    $secret_iv = 'my_simple_secret_iv';
 
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
 
    if( $action == 'e' ) {
        $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
    }
    else if( $action == 'd' ){
        $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
    }
 
    return $output;
}

function vms_register_operator_menu_page(){
    add_menu_page( 
        __( 'Mail Box', 'textdomain' ),
        'Mail Box',
        'publish_pages',
        'operator-option',
        'operators_threades',
        'dashicons-email'
    ); 
    add_submenu_page( 'operator-option', 'Mail details', 'Mail details','publish_pages', 'thread-details','thread_details_callback' );
    //
    
}

add_action( 'admin_menu', 'vms_register_operator_menu_page' );
function thread_details_callback(){
    require get_parent_theme_file_path( '/includes/backend/thread-details.php' );
}

/**
 * List of all user to operator threads
 */ 
add_action('admin_init','vms_operator_options');
function vms_operator_options() {
	if($_GET['page'] && $_GET['page'] == 'operator-option'){
		require get_parent_theme_file_path( '/includes/backend/operator-option.php' );
		wp_enqueue_script('backend-jquimin-js', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js' );
	}
	$SiteUsers = new SiteUsers();
	$role = $SiteUsers->_get_role($SiteUsers->user_id); 
	$SiteUsers    = new SiteUsers();
	$all_customer = $SiteUsers->_get_customer_users_email();
	wp_enqueue_style('backend-jqui-css', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css' );
	
	wp_enqueue_script('backend-js', get_theme_file_uri( '/includes/backend/js/common.js' ) );
    wp_enqueue_style('backend-custom-css', get_theme_file_uri( '/includes/backend/css/custom.css' ) );


    wp_localize_script( 'backend-js', 'wp_object', array( 'all_customer' => $all_customer ,'ajax_url' => admin_url('admin-ajax.php')) );
}

// User login
add_action("wp_ajax__user_sign", "_user_sign");
add_action("wp_ajax_nopriv__user_sign", "_user_sign");
function _user_sign(){
    $login_user = false;
    $profile = get_site_url().'/dashboard';
    $creds = array(
        'user_login'    => $_POST['email'],
        'user_password' => $_POST['psw'],
        'remember'      => $_POST['rem']
    );
    
    $user = wp_signon( $creds, false );
    $user_roles = ($user->roles); 
    if($user->data){
        if (in_array("operator", $user_roles) || in_array("administrator", $user_roles) ){
            $profile = admin_url();
        }
        $login_user = true;
        $res = array('login_user'=> $login_user,'msg'=> 'Successfully login','profile_url'=>$profile);
        
    }
    if($user->errors){
        $login_user = false;
        if($user->errors['invalid_username'] != ''){
            $res = array('login_user'=> $login_user , 'msg' => 'Invalid user name','error_code' => '101');
        }else if($user->errors['incorrect_password'] !=''){
            $res = array('login_user'=> $login_user , 'msg' => 'Invalid password','error_code' => '102');
        }else{
            $res = array('login_user'=> $login_user , 'msg' => 'Oops! something went wrong','error_code' => '103');
        }
    }

    wp_send_json($res);
    die(0);
}

/* Remove Contact Form 7 Links from dashboard menu items if not admin */
add_action('admin_menu', '_remove_contact_form_for_users');
function _remove_contact_form_for_users() {
    if (!(current_user_can('administrator'))) {
        remove_menu_page( 'wpcf7' ); 
    }
}

add_action('wp_ajax__thread_updated_complete','_thread_updated_complete');
add_action('wp_ajax_nopriv_thread_updated_complete','_thread_updated_complete');
function _thread_updated_complete(){
    global $wpdb;
    $table_name = $wpdb->prefix.'threads';   
    $thread_id = $_POST['thread_id'];
    $end_date = date('Y-m-d h:i:s A');
    $arg = array(
         'thread_ended_date' => $end_date
    );
    $where = array('id' => $thread_id);
    $status = $wpdb->update( $table_name,$arg,$where );
    echo $status;
    die(0);
}

//Check user exists or not by email for reset password and mail
add_action('wp_ajax___email_exists_or_not','__email_exists_or_not');
add_action('wp_ajax_nopriv___email_exists_or_not','__email_exists_or_not');
function __email_exists_or_not(){
    global $wpdb;
    $status = false;
    $user = get_user_by( 'email', $_POST['forgotEmail']);
    $user_id = $user->ID;
    if (isset($user_id) && $user_id > 0) {
        $status = true;
        //php mailer variables
        $encrepted_id = __string_crypt($user_id,'e');
        $admin = get_option('admin_email');
        $subject = "Reset passowrd";
        $headers = 'From: '. $admin . "\r\n" .
        'Reply-To: ' . $admin . "\r\n";
        $link = get_site_url().'/reset-password/?linkid='.$encrepted_id;
        $message = 'Dear '.$_POST['forgotEmail'].'</br></br>'.'<p>Reset password Link :  <a href="'.$link.'" >Click here</a></p>';
        //Here put your Validation and send mail
        $sent = wp_mail($_POST['forgotEmail'], $subject, $message, $headers);

    }
    echo $status;
    die(0);
}

//Reset password 
add_action('wp_ajax___reset_password','__reset_password');
add_action('wp_ajax_nopriv___reset_password','__reset_password');
function __reset_password(){
   $user = get_userdata( $_POST['user_id'] );
   if ( $user === false ) {
        echo 0;
    } else {
        $user_id = $user->data->ID;
        wp_set_password( $_POST['reset_psw'], $user_id );
        echo 1;
    }
    die(0);
}

// Disable admin for customer users
add_action('init', 'remove_admin_bar');
function remove_admin_bar() {
    if ( (current_user_can('customer'))) {
      show_admin_bar(false);
    }
    if ( is_admin() &&  current_user_can( 'customer' ) && ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
    wp_redirect( home_url() );
    exit;
    }
}
add_action('admin_footer','admin_custom_js');
function admin_custom_js(){
    echo '<script type="text/javascript">jQuery(document).ready(function($){
                    $("#createThread").click(function(){
                        $(".threadcontan").show();
                    });
                    $(".crs").click(function(){
                        $(".threadcontan").hide();
                    });
                });
            </script>';
}

// Front Dashboard thread detals
add_action('wp_ajax__dashboard_threadDetails','_dashboard_threadDetails');
add_action('wp_ajax_nopriv__dashboard_threadDetails','_dashboard_threadDetails');
function _dashboard_threadDetails(){
    global $wpdb;
    $html = '';
    $table = $wpdb->prefix.'threads';
    $SiteUsers = new SiteUsers();
    $current_user = get_current_user_id();
    $currentUsersData = $SiteUsers->_get_user_data_by_id($current_user);
    $to_user = $currentUsersData['user_login'];
    $to_user_img = $currentUsersData['avatar_url'];

    if($_POST['thread_id']){

        //Update row for seen
        $arg = array(
             'unread' => 1
        );
        $where = array('thread_id' => $_POST['thread_id']);
        $status = $wpdb->update( $table,$arg,$where );

        // Get all thread data with specific thread id
        $_details = $wpdb->get_results( "SELECT * FROM $table WHERE thread_id = ".$_POST['thread_id']." " );
        
        // Get particular row data
        $_row = $wpdb->get_results( "SELECT * FROM $table WHERE id = ".$_POST['rowId']." " );
        $from_user_id = $_row[0]->from;
        $fromUsersData = $SiteUsers->_get_user_data_by_id($from_user_id);
        $from_user = $fromUsersData['user_login'];
        $from_user_img = $fromUsersData['avatar_url'];
        $thread_title = $_row[0]->thread_title;
        $thread_created = $_row[0]->thread_created;
        $th_date = strtotime($thread_created);
        $threaDate = date('d M Y | H:m A',$th_date);

        $html .= '<div class="chat-header">
                    <input type="hidden" name="thread_id" id="thread_id" value="'.$_POST['rowId'].'">
                    <input type="hidden" name="thread_title" id="thread_title" value="'.$_row[0]->thread_title.'">
                    <input type="hidden" name="from_user_id" id="from_user_id" value="'.$from_user_id.'">
                    <div class="chat-profile">
                        <figure><img src="'.$from_user_img.'" alt=""></figure>
                        <div class="profile-details">
                            <h6>'.$thread_title.'</h6>
                            <p>'.$from_user.'</p>
                        </div>
                    </div>
                    <div class="chat-options">
                        <p>'.$threaDate.'</p>
                        <select name="customer_option" id="customer_option">
                            <option value="">-- Select option --</option>
                            <option value="Open & Scan Contents">Open & Scan Contents</option>
                            <option value="Hold for Pickup">Hold for Pickup</option>
                            <option value="Shred or Recycle">Shred or Recycle</option>
                            <option value="Forward to Another Address">Forward to Another Address</option>
                        </select>
                    </div>
                </div>
                <div class="chat-body">
                    <div class="chat-history">';
            $html .= '<span>Hi '.$to_user.',</span></br></br>';        
            foreach ($_details as  $details_value) {

                $thread_id = $details_value->thread_id;
                $from_user_id = $details_value->from;
                $to_user_id = get_current_user_id();
                $fromUsersData = $SiteUsers->_get_user_data_by_id($from_user_id);
               
                $from_user = $fromUsersData['user_login'];
                $from_user_img = $fromUsersData['avatar_url'];
                
                $thread_title = $details_value->thread_title;
                $thread_comment = $details_value->thread_comment;
                $files = $details_value->files;
                $customer_option = $details_value->customer_option;
                $files = $details_value->files;

                if($details_value->from != $current_user){
 

                  $html .= '<div class="conversation other-site">
                                <p>'.$thread_comment.'</p>
                            </div>'; 
                    if( unserialize($details_value->files) ){
                        $html .= '<span>Attachments :'; 
                         $num = 1; 
                            foreach (unserialize($details_value->files) as $url) {
                                $html .= '<a href="'.$url.'" download title="Download">File '.$num.'</a>&nbsp;&nbsp;&nbsp;';
                            $num++; 
                            }

                        $html .= '</span>';
                    }         

                }else{
                  $html .= '<div class="conversation my-site">
                            <p><span>Requested for : '.$customer_option.'</span>'.$thread_comment.'</p>
                            <figure><img src="'.$to_user_img.'" alt="" class="mCS_img_loaded"></figure>
                            </div>';   
                }  
            }            
            $html.='</div>
                </div>';
    }
    echo $html;
    die(0);
}

// Front Dashboard reply data
add_action('wp_ajax__dashboard_reply_thread','_dashboard_reply_thread');
add_action('wp_ajax_nopriv__dashboard_reply_thread','_dashboard_reply_thread');
function _dashboard_reply_thread(){
    global $wpdb;
    $table              = $wpdb->prefix.'threads';
    $html               = '';
    //print_r($_POST);
    $SiteUsers          = new SiteUsers();
    $customer_option    = $_POST['customer_option'];
    $reply_content      = $_POST['reply_content'];
    $thread_id          = $_POST['thread_id'];
    $from_user_id       = $_POST['from_user_id'];
    $fromUsersData      = $SiteUsers->_get_user_data_by_id($from_user_id);
    $currentUsersData   = $SiteUsers->_get_user_data_by_id(get_current_user_id());
    $from_user_img      = $currentUsersData['avatar_url'];
    $current_user_id    = get_current_user_id();
    $thread_title       = $_POST['thread_title'];
    $thread_created     = date('Y-m-d h:i:s A');

    $arg = array(
        'thread_id' => $thread_id,
        'from' => $current_user_id,
        'to' => $from_user_id,
        'files' => '',
        'thread_title' => $thread_title,
        'thread_comment' => $reply_content,
        'thread_created' => $thread_created,
        'thread_ended_date' => 0,
        'customer_option' => $customer_option,
        'unread' => 0
    );
    $status = $wpdb->insert( $table,$arg );
    $html .='<div class="conversation my-site"> <p>';

    if($customer_option != ''){
        $html .= '<span>Requested for : '.$customer_option.'</span>';
    }

    $html .= $reply_content.'</p><figure><img src="'.$from_user_img.'" alt="" class="mCS_img_loaded"></figure></div>';
    $return = array('status' => $status ,'html' => $html );
    wp_send_json($return);
    die(0);
}

// Update profile settings
add_action('wp_ajax__update_profile_settings','_update_profile_settings');
add_action('wp_ajax_nopriv__update_profile_settings','_update_profile_settings');
function _update_profile_settings(){
    global $wpdb;
    $user           = wp_get_current_user();
    $user_id        = $user->data->ID;
    $_streetname    = $_POST['_streetname'];
    $_cityname      = $_POST['_cityname'];
    $_countryname   = $_POST['_countryname'];
    $_phonenumber   = $_POST['_phonenumber'];
    $_aptno         = $_POST['_aptno'];
    $first_name     = $_POST['first_name'];
    $last_name      = $_POST['last_name'];
    $old_password   = $_POST['old_password'];
    $new_password   = $_POST['new_password'];
    $confirm_password   = $_POST['confirm_password'];

    if($old_password == "" && $new_password == "" && $confirm_password == ""){

        update_user_meta($user_id,'_streetname',$_streetname);
        update_user_meta($user_id,'_cityname',$_cityname);
        update_user_meta($user_id,'_countryname',$_countryname);
        update_user_meta($user_id,'_phonenumber',$_phonenumber);
        update_user_meta($user_id,'_aptno',$_aptno);
        update_user_meta($user_id,'first_name',$first_name);
        update_user_meta($user_id,'last_name',$last_name);
        update_user_meta($user_id,'nickname',$_POST['email']);
        update_user_meta($user_id,'_userpassword',$psw);
        $return = array('status' => 'success','error' => 200,'message' => 'Profile updated successfully.');
    }else if($new_password == "" && $confirm_password == "" && $old_password != ""){

        $return = array('status' => 'errors','error' => 401,'message' => 'Please give your new password');

    }else if($new_password != $confirm_password  && $old_password != ""){

        $return = array('status' => 'errors','error' => 401,'message' => 'Confirm password mismatch.');

    }else{   
        
        if($old_password != "" && $new_password != ""){
            $psw_status = wp_check_password( $old_password, $user->user_pass, $user->data->ID );

            if($psw_status){
                $args = array(
                    'ID'         => $user_id,
                    //'user_email' => esc_attr( $_POST['email'] ),
                    'user_pass' =>   $new_password
                );            
                $uid = wp_update_user( $args );
                if($uid){
                    $return = array('status' => 'success','error' => 200,'message' => 'Profile updated successfully.');
                }else{
                    $return = array('status' => 'errors','error' => 401,'message' => 'Sorry! Failed to update your account details.');
                }

            }else{
                $return = array('status' => 'errors','error' => 401,'message' => 'Wrong old password');
            }
        }else{
            $return = array('status' => 'success','error' => 200,'message' => 'Profile updated successfully.');
        }
    }   
    wp_send_json($return);
}

/*
* Creating a function to create our CPT
*/
 
function custom_post_type() {

    $labels = array(
        'name'                => _x( 'Faq', 'Post Type General Name', 'vms' ),
        'singular_name'       => _x( 'Faq', 'Post Type Singular Name', 'vms' ),
        'menu_name'           => __( 'Faqs', 'vms' ),
        'parent_item_colon'   => __( 'Parent Faq', 'vms' ),
        'all_items'           => __( 'All Faqs', 'vms' ),
        'view_item'           => __( 'View Faq', 'vms' ),
        'add_new_item'        => __( 'Add New Faq', 'vms' ),
        'add_new'             => __( 'Add New', 'vms' ),
        'edit_item'           => __( 'Edit Faq', 'vms' ),
        'update_item'         => __( 'Update Faq', 'vms' ),
        'search_items'        => __( 'Search Faq', 'vms' ),
        'not_found'           => __( 'Not Found', 'vms' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'vms' ),
    );
    $args = array(
        'label'               => __( 'faqs', 'vms' ),
        'description'         => __( 'Faq news and reviews', 'vms' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
        'taxonomies'          => '',
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );
    register_post_type( 'faqs', $args );
 }
add_action( 'init', 'custom_post_type', 0 );

/*
* Find number of difference between two dates 
*/
function dateDifference($date1, $date2) {
  $date1_ts = strtotime($date1);
  $date2_ts = strtotime($date2);
  $diff = $date2_ts - $date1_ts;
  return round($diff / 86400);
}