<?php 
function _partner_result_template_user($user_id){

	global $wpdb;
	$tab_result = $wpdb->prefix.'users';
	$user_result = $wpdb->get_row("SELECT * FROM $tab_result WHERE ID =".$user_id );
	$username = $user_result->display_name;

	$html_partner_user = ob_start();
?>
	<html>
	<head>
	<meta charset="UTF-8"> 
	</head>
	<body style="font-family: verdana;background-color: #ddd;font-size: 14px;color: #333;">
        <div style=" border: 1px solid #ccc;border-radius: 0px; background-color: #fff; margin: 40px auto;width: 650px;padding: 30px">
        <div style="background-color: rgba(174, 195, 200, 0.6);padding: 10px; text-align:center;"><img src="<?php echo home_url(); ?>/wp-content/uploads/2019/02/logo.png"></div>
            <div style="line-height: 1.6em; margin-top: 20px;">
            <p>Dear <b><?php echo ucfirst($username); ?>,</b></p>
            <!-- <p>Your Password is <b><?php echo $getgenpassword[0]; ?></b></p> -->
            <p>Your profile has been successfully registerd.</p>								
			</div>
			<div style="margin-top: 50px;">
				<p>Thank You,</p>
				<p><strong>Virtual Post Jamaica Team</strong></p>
			</div> 
</div>
 </body>
</html>
<?php
	$html_partner_user = ob_get_clean();
	return $html_partner_user;
}
?>
<?php
function _partner_result_template_admin($user_id){

	global $wpdb;
	$tab_result1 = $wpdb->prefix.'users';
	$user_result1 = $wpdb->get_row("SELECT * FROM $tab_result1 WHERE ID =".$user_id );
	$partnername = $user_result1->display_name;
	$prtner_email = $user_result1->user_email;

	$business_name = get_user_meta( $user_id, '_businessname');
	$apt_no = get_user_meta( $user_id, '_aptno');
	$street_name = get_user_meta( $user_id, '_streetname');
	$city_name = get_user_meta( $user_id, '_cityname');
	$country_name = get_user_meta( $user_id, '_countryname');
	$phone_no = get_user_meta( $user_id, '_phonenumber');
	$usertype = get_user_meta( $user_id, '_usertype');
	// $getgenpassword = get_user_meta( $user_id, '_userpassword');
	$html_partner_admin = ob_start();
?>
	<html>
	<head>
	<meta charset="UTF-8"> 
	</head>
	<body style="font-family: verdana;background-color: #ddd;font-size: 14px;color: #333;">
        <div style=" border: 1px solid #ccc;border-radius: 0px; background-color: #fff; margin: 40px auto;width: 650px;padding: 30px">
        <div style="background-color: rgba(174, 195, 200, 0.6);padding: 10px; text-align:center;"><img src="<?php echo home_url(); ?>/wp-content/uploads/2019/02/logo.png"></div>
            <div style="line-height: 1.6em;">
            <p>Dear <b>Admin,</b></p>
            <!-- <p>Password is <b><?php echo $getgenpassword[0]; ?></b></p> -->
            <p>User Registration Details</p>
			<table style="margin:0 auto; width: 100%;" cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<td valign="top">
							<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #000; padding:15px;">
								<tbody>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
										Name  :
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
										<strong> <?php echo $partnername; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Email:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $prtner_email; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Phone no:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $phone_no[0]; ?></strong>
										</td>
									</tr>								
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Type of user:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo ucfirst($usertype[0]); ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											
										Business Name :
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong> <?php echo $business_name[0]; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Apt no:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $apt_no[0]; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Street Address:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $street_name[0]; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											City/Town:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $city_name[0]; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Country Name:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $country_name[0]; ?></strong>
										</td>
									</tr>	
								</tbody>
							</table>
						</td>
					</tr>
				</tbody>
			</table>								
			</div> 
</div>
 </body>
</html>
	<?php
	$html_partner_admin = ob_get_clean();
	return $html_partner_admin;
}
?>

<?php 
//Customer Sign UP Mail for User//

function _customer_result_template_user($cust_id){

	global $wpdb;
	$tab_result = $wpdb->prefix.'users';
	$user_result = $wpdb->get_row("SELECT * FROM $tab_result WHERE ID =".$cust_id );
	$username = $user_result->display_name;

	$html_customer_user = ob_start();
?>
	<html>
	<head>
	<meta charset="UTF-8"> 
	</head>
	<body style="font-family: verdana;background-color: #ddd;font-size: 14px;color: #333;">
        <div style=" border: 1px solid #ccc;border-radius: 0px; background-color: #fff; margin: 40px auto;width: 650px;padding: 30px">
        <div style="background-color: rgba(174, 195, 200, 0.6);padding: 10px; text-align:center;"><img src="<?php echo home_url(); ?>/wp-content/uploads/2019/02/logo.png"></div>
            <div style="line-height: 1.6em; margin-top: 20px;">
            <p>Dear <b><?php echo ucfirst($username); ?>,</b></p>
            <!-- <p>Your Password is <b><?php echo $getgenpassword[0]; ?></b></p> -->
            <p>Your profile has been successfully registerd.</p>								
			</div>
			<div style="margin-top: 50px;">
				<p>Thank You,</p>
				<p><strong>Virtual Post Jamaica Team</strong></p>
			</div> 
</div>
 </body>
</html>
<?php
	$html_customer_user = ob_get_clean();
	return $html_customer_user;
}
?>
<?php
//Customer Sign UP Mail for Admin//

function _customer_result_template_admin($cust_id){
	global $wpdb;
	$tab_result1 = $wpdb->prefix.'users';
	$user_result1 = $wpdb->get_row("SELECT * FROM $tab_result1 WHERE ID =".$cust_id );
	$customername = $user_result1->display_name;
	$customer_email = $user_result1->user_email;

	$company_name = get_user_meta( $cust_id, '_companyname');
	$apt_no = get_user_meta( $cust_id, '_aptno');
	$street_name = get_user_meta( $cust_id, '_streetname');
	$city_name = get_user_meta( $cust_id, '_cityname');
	$country_name = get_user_meta( $cust_id, '_countryname');
	$phone_no = get_user_meta( $cust_id, '_phonenumber');
	$usertype = get_user_meta( $cust_id, '_usertype');
	$html_customer_admin = ob_start();
?>
	<html>
	<head>
	<meta charset="UTF-8"> 
	</head>
	<body style="font-family: verdana;background-color: #ddd;font-size: 14px;color: #333;">
        <div style=" border: 1px solid #ccc;border-radius: 0px; background-color: #fff; margin: 40px auto;width: 650px;padding: 30px">
        <div style="background-color: rgba(174, 195, 200, 0.6);padding: 10px; text-align:center;"><img src="<?php echo home_url(); ?>/wp-content/uploads/2019/02/logo.png"></div>
            <div style="line-height: 1.6em;">
            <p>Dear <b>Admin,</b></p>
            <!-- <p>Password is <b><?php echo $getgenpassword[0]; ?></b></p> -->
            <p>User Registration Details</p>
			<table style="margin:0 auto; width: 100%;" cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<td valign="top">
							<table width="100%" align="center" cellpadding="0" cellspacing="0" border="0" style="border:1px solid #000; padding:15px;">
								<tbody>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
										Name  :
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
										<strong> <?php echo $customername; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Email:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $customer_email; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Phone no:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $phone_no[0]; ?></strong>
										</td>
									</tr>								
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Type of user:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo ucfirst($usertype[0]); ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											
										Company Name :
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong> <?php echo $company_name[0]; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Apt no:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $apt_no[0]; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Street Address:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $street_name[0]; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											City/Town:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $city_name[0]; ?></strong>
										</td>
									</tr>
									<tr>
										<td valign="top" align="left" width="180" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											Country Name:
										</td>
										<td valign="top" align="left" style="font-size:13px; line-height:20px; color:#000; padding:2px 0px;">
											<strong><?php echo $country_name[0]; ?></strong>
										</td>
									</tr>	
								</tbody>
							</table>
						</td>
					</tr>
				</tbody>
			</table>								
			</div> 
</div>
 </body>
</html>
	<?php
	$html_customer_admin = ob_get_clean();
	return $html_customer_admin;
}
?>