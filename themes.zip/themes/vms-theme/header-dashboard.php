<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
	<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' |'; } ?> <?php bloginfo('name'); ?></title>
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
	<!-- Custom css -->
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() ?>/css/dashboard.css">
	<!-- custom scrollbar css -->
	<link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/css/mCustomScrollber.css">
	<?php wp_head(); ?>
</head>
<body>
	<!-- Header -->
	<header id="header" class="site-header">
		<div class="logo">
			<?php $header_logo = get_field('logo_header','option'); ?>
			<a href="<?php echo home_url(); ?>" title=""><img src="<?php echo $header_logo['url']; ?>" alt=""></a>
		</div>
		<div class="right-header">
			<a href="<?php echo wp_logout_url(home_url()); ?>" title="" class="logout">
				<img src="<?php echo get_template_directory_uri() ?>/images/icon-logout.png" alt="">
				Log Out
			</a>
			<a href="javascript:void(0);" class="toggle">
				<span></span>
				<span></span>
				<span></span>
			</a>
		</div>
	</header>
	<?php 
		global $wpdb,$post;
    	$tablename = $wpdb->prefix.'threads';
		$user_id = get_current_user_id();
		$SiteUsers = new SiteUsers();
		$SiteUsersData = $SiteUsers->_get_user_data_by_id($user_id);
		$unread_thread = $wpdb->get_var( "SELECT count(*) FROM `$tablename` WHERE `to` = ".$user_id." AND `unread` = 0 " );
		$page_id =  get_the_ID() ; 
		if( $page_id == 410 ){
			$dashboard = "active";
		}else{
			$dashboard = "";
		}
		if($page_id == 455 ){
			$profile = "active";
		}else{
			$profile = "";
		}
	?>
	<div class="main-content">
		<div class="left-aside">
			<div class="dashboard-user">
				<figure>
					<?php if($SiteUsersData['avatar_url'] == ""){ ?>
						<img src="<?php echo get_template_directory_uri() ?>/images/dashboard-user.jpg" alt="No image">
					<?php }else{ ?>
						<img src="<?php echo $SiteUsersData['avatar_url']; ?>" alt="No image">
					<?php } ?>

				</figure>
				<div class="data">
					<h4>Welcome</h4>
					<h5><?php echo ucfirst($SiteUsersData['metadata']['first_name']); ?></h5>
				</div>
			</div>
			<nav>
				<ul>
					<li class="dashboard <?php echo $dashboard; ?>">
						<a href="<?php echo home_url('dashboard'); ?>" title="">Dashboard 
							<?php if($unread_thread > 0) { ?>
								<span><?php echo $unread_thread; ?></span>
							<?php } ?>
						</a>
					</li>
					<li class="profile-settings <?php echo $profile; ?>"><a href="<?php echo home_url('profile-settings'); ?>" title="">Profile Settings</a></li>
				</ul>
			</nav>
		</div>