jQuery(document).ready(function(){
	var availableUsers = wp_object.all_customer;
	jQuery( "#users" ).autocomplete({
      source: availableUsers,      
      response: function( event, ui ) {
        var added = [];//Keep here the unique labels that are already in the list
        for(var i=ui.content.length-1;i>=0;i--){//Start a loop, itterate all items backwards
          var cur = ui.content[i].value;//Value of the item
          if($.inArray(cur,added)==-1){//If not already loaded
            added.push(cur);//Put the new item in the list
          }else{            
            ui.content.splice(i,1);//If already loaded remove it from the results
          }
        }        
      }
    });
    $(document).on('click','.completed',function(){

      var thread_id = $(this).data('id');
      var data = {'thread_id':thread_id,'action':'_thread_updated_complete'}
      if (confirm('Are you sure complete this thread ?')) {
        $('.main-loader').show();
        jQuery.ajax({
           type : "post",
           url : wp_object.ajax_url,
           data : data,
           success: function(response) {
              $('.main-loader').hide(); 
              if(response == 1){
                alert('Thread completed.');
                location.reload();
              }else{
                alert('Opps! Something went wrong, Try again.');
              }
           }
        });
      }  
    });
});