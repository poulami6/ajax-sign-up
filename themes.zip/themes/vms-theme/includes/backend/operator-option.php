<?php 
if (isset($_POST['send-thread'])) {
	global $wpdb;
    $tablename = $wpdb->prefix.'threads';
	$userdata 	=   get_user_by('email',$_POST['user']);
    $to_user 	= $userdata->ID;
    $from_user 	= get_current_user_id();
    $thread_title = $_POST['title'];
    $thread_comment = $_POST['thread_comment'];
    $thread_created = date('Y-m-d h:i:s A');
    $arg = array(
        'thread_id' => '',
    	'from' => $from_user,
    	'to' => $to_user,
        'files' => '',
    	'thread_title' => $thread_title,
    	'thread_comment' => $thread_comment,
    	'thread_created' => $thread_created,
        'thread_ended_date' => 0,
        'customer_option' => '',
        'unread' => 0
    );
    $status = $wpdb->insert( $tablename,$arg );
    $lastid = $wpdb->insert_id;
    $thread_data = array('thread_id' => $lastid);
    $where = array('id' => $lastid);
    $wpdb->update( $tablename,$thread_data,$where );
 //echo $wpdb->last_query;
}
/**
* Notification bar
*/
class WPSE_updated_Message {
    private $_message;

    function __construct( $message ) {
        $this->_message = $message;

        add_action( 'admin_notices', array( $this, 'render' ) );
    }

    function render() {
        printf( '<div class="updated notice is-dismissible"><p><strong>%s</strong></p></div>', $this->_message );
    }
}
class WPSE_error_Message {
    private $_message;

    function __construct( $message ) {
        $this->_message = $message;

        add_action( 'admin_notices', array( $this, 'error_render' ) );
    }

    function error_render() {
        printf( '<div class="error notice is-dismissible"><p><strong>%s</strong></p></div>', $this->_message );
    }
}
if(isset($_POST['send-thread']) && $status == 1 ){
    new WPSE_updated_Message( "Thread has been created." );
}
if(isset($status) && $status != 1 ){
    new WPSE_error_Message( "Select valid user" );
}

/**
 * In this part you are going to define custom table list class,
 * that will display your database records in nice looking table
 * http://codex.wordpress.org/Class_Reference/WP_List_Table
 * http://wordpress.org/extend/plugins/custom-list-table-example/
 */

if (!class_exists('WP_List_Table')) {

    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

/**
 * bc_booking_system_List_Table class that will display our custom table
 * records in nice table
 */

class WQ_operators_threades_Table extends WP_List_Table
{

    //[REQUIRED] You must declare constructor and give some basic params

    function __construct()
    {
        global $status, $page;
        parent::__construct(array(
		
            'singular' => 'project',
            'plural' => 'projects',
        ));
    }



    /*
     * [REQUIRED] this is a default column renderer
     * @param $item - row (key, value array)
     * @param $column_name - string (key)
     * @return HTML
     */

    function column_default($item, $column_name)
    {
		global $wpdb;
        $table_name = $wpdb->prefix.'threads';  
        $SiteUsers = new SiteUsers();
        $SiteUsersData = $SiteUsers->_get_user_data_by_id($item[$column_name]);
        $icon          = get_template_directory_uri().'/includes/backend/images/done.png';

        $specific_details = $wpdb->get_results( "SELECT * FROM $table_name WHERE id = ".$item['thread_id']." " );
        $thread_ended_date = $specific_details[0]->thread_ended_date;
		switch($column_name) {

            case 'to':
			return $SiteUsersData['user_login'];
            case 'view':
            $view = sprintf('<a href="?page=%s&action=view&thread=%s">%s</a>', __('thread-details'), $item['thread_id'], __('Click') );
            return $view;

            case 'action':
            if($thread_ended_date == 0){
                $complete = sprintf('<a href="javascript:void(0)" class="completed" data-id="%s">%s</a>',$item['thread_id'],__('Complete') );
            }else{
                $complete = sprintf('<img src="%s">',$icon);
            }
            return $complete;

            case 'enddate':
            if($thread_ended_date !=0){
                $enddate = sprintf($thread_ended_date);
            }else{
                $enddate = sprintf('--');
            }
            
            return $enddate;
            
		
            default:
               return $item[$column_name];
        }        
    }



    /**
     * [OPTIONAL] this is example, how to render specific column
     * method name must be like this: "column_[column_name]"
     * @param $item - row (key, value array)
     * @return HTML
     */

   //  function column_id($item)
   //  {
   //      $actions = array(

   //          //'edit' => sprintf('<a href="admin.php?page=%snew_meal_item&action=edit&id=%s">%s</a>', $_REQUEST[''], $item['item_id'], __('Edit', 'bc_booking_system')),
   //          'delete' => sprintf('<a href="?page=%s&action=delete&id=%s">%s</a>', $_REQUEST['page'], $item['item_id'], __('Delete', 'bc_booking_system')),
			// 'view' => sprintf('<a href="?page=%s&action=view&id=%s">%s</a>', $_REQUEST['page'], $item['ID'], __('View', 'bc_booking_system')),
   //      );

   //      return sprintf('%s %s',

   //          $item['id'],
   //          $this->row_actions($actions)
   //      );

   //  }
	
    /**
     * [REQUIRED] this is how checkbox column renders
     * @param $item - row (key, value array)
     * @return HTML
     */

    function column_cb($item)
    {
        return sprintf(

            '<input type="checkbox" name="id[]" value="%s" />',
            $item['id']
        );
    }

    /**

     * [REQUIRED] This method return columns to display in table
     * you can skip columns that you do not want to show
     * like content, or description
     * @return array
     */

    function get_columns()
    {
        $columns = array(

            'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
			'id' => __('# Thread id'),
			'to' => __('To'),
            'thread_title' => __('Title'),
            'thread_comment' => __('Message'),
            'enddate' => __('Completed date'),
            'thread_created' => __('Created Date'),
            'view' => __('View'),
            'action' => __('Action'),
			//'item_name' => __('Item Name'),
			//'item_price' => __('Item price (Rs.)')
	    );

        return $columns;
    }




    /*
     * [OPTIONAL] This method return columns that may be used to sort table
     * all strings in array - is column names
     * notice that true on name column means that its default sort
     * @return array
     */

    function get_sortable_columns()
    {
        $sortable_columns = array(
		
            'timestamp' => array('timestamp', true),
        );

        return $sortable_columns;
    }
	
	
	//Use the "manage{$page}columnshidden" option, maintained by WordPress core:
	function get_hidden_columns(){
		
		$columns =  (array) get_user_option( 'managetoplevel_page_messagescolumnshidden' );
        return $columns;
    }

    /*
     * [OPTIONAL] Return array of bult actions if has any
     * @return array
     */

    function get_bulk_actions()
    {
        $actions = array(

            'delete' => 'Delete',
        );

        return $actions;
    }


    /*
     * [OPTIONAL] This method processes bulk actions
     * it can be outside of class
     * it can not use wp_redirect coz there is output already
     * in this example we are processing delete action
     * message about successful deletion will be shown on page in next part
     */

    function process_bulk_action()
    {
        global $wpdb;

        $table_name = $wpdb->prefix.'threads'; // do not forget about tables prefix
		
        if ('delete' === $this->current_action()) {

            $ids = isset($_REQUEST['id']) ? $_REQUEST['id'] : array();

            if (is_array($ids)) $ids = implode(',', $ids);

            if (!empty($ids)) {

                $wpdb->query("DELETE FROM $table_name WHERE id IN($ids)");
            }

        }

    }

    /**
     * [REQUIRED] This is the most important method
     * It will get rows from database and prepare them to be showed in table
     */

    function prepare_items()
    {
        global $wpdb,$current_user;
        $group = 'thread_id';
        $_user_id = get_current_user_id();
        $_row = 'from';
        $table_name = $wpdb->prefix.'threads'; // do not forget about tables prefix
        $per_page = 10;
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();
		
        // here we configure table headers, defined in our methods
        $this->_column_headers = array($columns, $hidden, $sortable);
		
        // [OPTIONAL] process bulk action if any
        $this->process_bulk_action();
		
        // will be used in pagination settings
        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");
		
        // prepare query params, as usual current page, order by and order direction

        $paged = isset($_REQUEST['paged']) ? max(0, intval($_REQUEST['paged']) - 1) : 0;

        $orderby = (isset($_REQUEST['orderby']) && in_array($_REQUEST['orderby'], array_keys($this->get_sortable_columns()))) ? $_REQUEST['orderby'] : 'id';

        $order = (isset($_REQUEST['order']) && in_array($_REQUEST['order'], array('asc', 'desc'))) ? $_REQUEST['order'] : 'desc';
		
        if (isset($_POST['s'])) {
            $sql =   'SELECT * FROM wp_threads WHERE thread_title LIKE "%'.$_POST['s'].'%" OR thread_comment LIKE "%'.$_POST['s'].'%" OR id LIKE "%'.$_POST['s'].'%" OR thread_created LIKE "%'.$_POST['s'].'%" ';
        }else{
           // $sql = "SELECT * FROM $table_name ORDER BY $orderby $order LIMIT %d OFFSET %d ";
            
            $sql = "SELECT DISTINCT *  FROM $table_name WHERE `$_row` = $_user_id GROUP BY `$group` ORDER BY $orderby $order LIMIT %d OFFSET %d ";
        }
		//$sql = "SELECT * FROM $table_name ORDER BY $orderby $order LIMIT %d OFFSET %d ";
			
        $this->items = $wpdb->get_results($wpdb->prepare($sql, $per_page, $paged), ARRAY_A);

        $total_items = count($this->items);
        //print_r($this->items);

        $this->set_pagination_args(array(

            'total_items' => $total_items, // total items defined above
            'per_page' => $per_page, // per page constant defined at top of method
            'total_pages' => ceil($total_items / $per_page) // calculate pages count
        ));
    }
}



/*
 * List page handler
 * This function renders our custom table
 * Notice how we display message about successfull deletion
 * Actualy this is very easy, and you can add as many features
 * as you want.
 * Look into /wp-admin/includes/class-wp-*-list-table.php for examples
 */

function operators_threades()
{


    global $wpdb;
	
    $table = new WQ_operators_threades_Table();

    $table->prepare_items();
	
    $message = '';

    if ('delete' === $table->current_action()) {

        $message = '<div class="updated below-h2" id="message"><p>' . sprintf(__('Items deleted: %d', 'bc_booking_system'), count($_REQUEST['id'])) . '</p></div>';
    }

    ?>

<div class="wrap">

    <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
    
	<?php 
		if('edit' === $table->current_action()){
			
			require_once(BDR_PLUGIN_DIR.'/admin-template/template-edit-birthday.php');
			
		} else if('view' === $table->current_action()){
			
			//require_once(BDR_PLUGIN_DIR.'/admin-templates/view-maintenance.php');
			
		}
		else{
	?>

   


    <input type="hidden" class="date_day" value="<?php echo date('d');?>">
    <h2 class="main_head"><span><?php _e('Threads')?></span> &nbsp;&nbsp;<a href="#" class="add-new-h2" id="createThread">Create thread</a>
    </h2> 
    <?php echo $message; ?>
	<!-- <form action="" method="post">
        <input type="search" name="s" placeholder="Search"><?php if(isset($_POST['s'])) { echo "<span>Search result for </b>". $_POST['s']."</b></span>"; } ?>

    </form> -->

    <form id="persons-table" method="GET" class="mytable">
        <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>"/>
        <?php $table->display() ?>
    </form>
 	<?php /*?><div class="loader_area" style="display:none;"><img src="<?php echo BDR_PLUGIN_URL .'/images/loader.gif'?>"></div><?php */?>
   

	<?php } ?>
    
    
</div>

<?php

}?>      

<div class="main-loader" style="display: none;">
    <div class="loader-inner" >
    <h1 class="wp-heading-inline">Loading...</h1>
    </div>
</div>

<div class="threadcontan" style="display: none;">
			<div class="thread-inner" id="threade-page" >
			<h1 class="wp-heading-inline">Create a new thread</h1>
			<span class="crs">x</span>
			<form id="threads" action="" method="post">
				<p></p>
				<p><input type="email" class="regular-text code" name="user" value="" id="users" placeholder="Customer email" required></p>
				<p><input type="text" class="regular-text code" name="title" value="" id="title" placeholder="Thread title" required></p>
				<p><textarea rows="10" cols="50" name="thread_comment" class="regular-text code" placeholder="Thread message"></textarea></p>
				<p class="submit">
					<input type="submit" name="send-thread" id="send" class="button button-primary" value="Send">
				</p>
			</form>
			</div>
</div>