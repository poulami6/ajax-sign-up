<?php 
	if( isset($_GET['action']) && $_GET['action'] == 'view' && isset($_GET['thread']) && !empty($_GET['thread']) ){ 
	global $wpdb;
	$table_name = $wpdb->prefix.'threads';	
	//Get specific data

	$specific_details = $wpdb->get_results( "SELECT * FROM $table_name WHERE id = ".$_GET['thread']." " );
	$to = $specific_details[0]->to;
	$title = $specific_details[0]->thread_title;
	$thread_ended_date = $specific_details[0]->thread_ended_date;

	if(isset($_POST['filesub'])){
		if ( ! function_exists( 'wp_handle_upload' ) ) {
	    	require_once( ABSPATH . 'wp-admin/includes/image.php' );
	        require_once( ABSPATH . 'wp-admin/includes/file.php' );
	        require_once( ABSPATH . 'wp-admin/includes/media.php' );
		}
		$files = $_FILES['upload_attachment'];
	    $count = 0;
	    $file_uploaded = array();
	    foreach ($files['name'] as $count => $value) {

	        if ($files['name'][$count]) {

	            $file = array(
	                'name'     => $files['name'][$count],
	                'type'     => $files['type'][$count],
	                'tmp_name' => $files['tmp_name'][$count],
	                'error'    => $files['error'][$count],
	                'size'     => $files['size'][$count]
	            );
	            $mims = array(
	            	'jpg|jpeg|jpe'  => 'image/jpeg',
					'gif'           => 'image/gif',
					'png'  			=> 'image/png',
				);
	            $upload_overrides = array( 'test_form' => false,'mims'=> $mims );
	            $upload = wp_handle_upload($file, $upload_overrides);
	            $file_uploaded[] =  $upload['url'];
	            //var_dump($upload);
	        }
	    }
	    
	    $message = $_POST['message'];
	    $thread_created = date('Y-m-d h:i:s A');
	    $from = get_current_user_id();
	    $attachDATA = serialize($file_uploaded);
	    $arg = array(
	        'thread_id' => $_GET['thread'],
	    	'from' => $from,
	    	'to' => $to,
	        'files' => $attachDATA,
	    	'thread_title' => $title,
	    	'thread_comment' => $message,
	    	'thread_created' => $thread_created,
	    	'thread_ended_date' => 0,
	    	'customer_option' => '',
	    	'unread' => 0
	    );
	    $status = $wpdb->insert( $table_name,$arg );
	    //echo $wpdb->last_query;      
	}
/**
* Notification bar
*/
class Notice_updated_Message {
    private $_message;

    function __construct( $message ) {
        $this->_message = $message;

        add_action( 'admin_notices', array( $this, 'suc_render' ) );
    }

    function suc_render() {
        printf( '<div class="updated notice is-dismissible"><p><strong>%s</strong></p></div>', $this->_message );
    }
}
class Notice_error_Message {
    private $_message;

    function __construct( $message ) {
        $this->_message = $message;

        add_action( 'admin_notices', array( $this, 'error_render' ) );
    }

    function error_render() {
        printf( '<div class="error notice is-dismissible"><p><strong>%s</strong></p></div>', $this->_message );
    }
}
$current_user = get_current_user_id();
$thread_details = 	$wpdb->get_results( "SELECT * FROM $table_name WHERE `thread_id` = ".$_GET['thread']."" );
?>
<div class="main-thread-content">	
<h3><?php echo $thread_details[0]->thread_title; ?></h3>
<?php 
	if(isset($_POST['filesub']) && $status == 1 ){
	    echo '<div class="updated notice is-dismissible"><p><strong>Thread submitted.</strong></p></div>';
	}
	if(isset($status) && $status != 1 ){
	    echo '<div class="error notice is-dismissible"><p><strong>Opps!! Something went wrong.</strong></p></div>';
	}
?>
	<div class="thread-content">
		<ul>
			<?php 
			    $count = 1;
			    foreach ($thread_details as $thread_value) {
				$userdata_from 	=   get_user_by('ID',$thread_value->from);
				$from_user_email 	= $userdata_from->user_email;
    			$userdata_to 	=   get_user_by('ID',$thread_value->to);
    			$to_user_email 	= $userdata_to->user_email;
    			$current_user 	= get_current_user_id();
    			
			?>
				<li class="thread <?php echo $count; ?>">
					<time> Thread date: <?php echo $thread_value->thread_created; ?></time></br>
					<span> From: </span> <?php echo $from_user_email; ?> &nbsp;&nbsp;&nbsp;
					<span> To: </span> <?php echo $to_user_email; ?></br></br>

					<?php if($thread_value->customer_option) { ?>
						<span>Customer Option: </span><?php echo $thread_value->customer_option; ?></br></br>
					<?php } ?>

					<span>Message: </span><?php echo $thread_value->thread_comment; ?>
					<?php if( unserialize($thread_value->files) ){ ?>
						<p>Attachments : 
						  <?php $num = 1; foreach (unserialize($thread_value->files) as $url) {
						  	echo '<a href="'.$url.'" download>File '.$num.'</a>&nbsp;&nbsp;&nbsp;';
						   $num++; }
						   ?>
						</p>   
					<?php } ?>
				</li>

		     <?php $count++; } ?>	
		     <form class="<?php if($thread_ended_date != 0){ ?>formDisable<?php } ?>" method="post" action="" enctype="multipart/form-data">
		     	<textarea name="message" required></textarea>
		     	<input type="file" name="upload_attachment[]" accept="image/png,image/jpeg" multiple>
		     	<input type="submit" name="filesub" class="button button-primary" value="Send">
		     </form>
		</ul>
	</div>
</div>	


<?php 
	}else{
		$location = admin_url( '/admin.php?page=operator-option');
		print('<script>window.location.href="'.$location.'"</script>');
	}
?>