<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since 1.0.0
 */

get_header();
?>
<div id="content" class="site-content">
				
<!-- Banner -->
<div class="banner inner-banner">
	<div class="container">
		<div class="first-image">
			<img src="<?php echo get_template_directory_uri().'/images/inner-banner-image.png';?>" alt="">
		</div>
		<div class="page-heading">
			<div class="company-headlines">
				<h2>Page not found !</h2>
			</div>
		</div>
		<div class="last-image">
			<img src="<?php echo get_template_directory_uri().'/images/inner-banner-girl.png';?>" alt="">
		</div>
	</div>
</div>

<!-- Fingertips -->
<div class="login-outer">
	<div class="container">
		<div class="contact-from-inr contact-from-inr-main">
			<div class="404content">
				<div class="left-content">
					<p>Page Not Found! Sorry, We couldn't find the page you're looking for.
	Try returning to the </p>
	<a class="text-button" href="<?php echo site_url(); ?>"> homepage</a>
				</div>
				<div class="right-content">
					<img src="<?php echo get_template_directory_uri().'/images/404.png';?>">
				</div>
			</div>
				
			
		</div>	
	</div>
</div>

<?php get_footer();
