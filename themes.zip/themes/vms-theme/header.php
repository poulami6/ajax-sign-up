<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
	<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' |'; } ?> <?php bloginfo('name'); ?>

</title>
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
	<!-- Wordpress Defolt css -->
	<link rel="stylesheet" href="<?php echo get_template_directory_uri() ?>/style.css">
	<!-- Owl Carousel Assets -->
    <link href="<?php echo get_template_directory_uri() ?>/css/owl.carousel.min.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri() ?>/css/owl.theme.default.min.css" rel="stylesheet">
    <?php wp_head(); ?>
</head>
<body>
	<div id="page" class="site">
		<div class="site-inner">
			<!-- Header -->
			<header id="masthead" class="site-header" role="banner">
				<div class="site-header-main">
					<div class="site-branding">
						<div class="site-title">
							<?php $header_logo = get_field('logo_header','option'); ?>
							<a href="<?php echo home_url(); ?>"><img src="<?php echo $header_logo['url']; ?>" alt=""></a>
						</div>
					</div>
					<div class="right-header">
						<nav id="site-navigation" class="main-navigation" role="navigation">
							<?php wp_nav_menu( array( 'theme_location' => 'primary' , 'container' => '','menu_class' => 'primary-menu' ) ); ?>							
						</nav>
						<ul class="user-login">
						<?php if(is_user_logged_in()) { ?>
							<li><a href="<?php echo wp_logout_url(home_url()); ?>" title="">Logout</a></li>
						<?php }else{ ?>
							<li><a href="<?php echo home_url('/sign-in'); ?>" title="">Login</a></li>
						<?php } ?>
						<?php if(!is_user_logged_in()) { ?>
							<li><a href="<?php echo home_url('/sign-up/'); ?>" title="">Sign Up</a></li>
						<?php } ?>	
						</ul>
					</div>
					<a href="javascript:void(0);" class="toggleMenu">
						<span></span>
						<span></span>
						<span></span>
					</a>
				</div>
			</header>