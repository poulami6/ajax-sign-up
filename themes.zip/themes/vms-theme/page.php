<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since 1.0.0
 */

get_header();
global $post; 
$content_post = get_post(get_the_ID());
$content = $content_post->post_content;
$title = $content_post->post_title;
$content = apply_filters('the_content', $content);
?>

<div id="content" class="site-content">
				
	<!-- Banner -->
	<div class="banner inner-banner">
		<div class="container">
			<div class="first-image">
				<img src="<?php echo get_field('banner_image',get_the_ID()); ?>" alt="banner image">
			</div>
			<div class="page-heading">
				<div class="company-headlines">
					<h2><?php echo get_field('banner_text',get_the_ID()); ?></h2>
				</div>
			</div>
			<div class="last-image">
				<img src="<?php echo get_field('banner_inner_image',get_the_ID()); ?>" alt="banner image">
			</div>
		</div>
	</div>
<!-- Privacy Policy -->
	<div class="privacy-policy terms-condition">
		<div class="container">
			<h2 class="elementor-heading-title"><?php echo get_field('banner_text',get_the_ID()); ?></h2>
			<?php echo $content; ?>
		</div>
	</div>
	</div>

<?php get_footer(); ?>
