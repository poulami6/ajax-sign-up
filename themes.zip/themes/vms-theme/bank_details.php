
<!-- validation-->
<div class="car-allresults">
	<h2>Update Bank Details</h2>

	<?php $ajax_url = admin_url('admin-ajax.php'); ?>

	<?php 
		global $wpdb;	
		$tab2 = $wpdb->prefix.'direct_transfer';
		$single_result = $wpdb->get_row("SELECT * FROM $tab2 WHERE id=1");
		 
		$limitid = $single_result->id;

	?>

	<div class="queryform-wrap">
		
		<form name="wp_user_form" id="example-form" action="" method="post">
			<fieldset>
			<h2>Sagicor Bank</h2>
			<div class="card-js form-group">
				<ul>
					<li>
						<span>Add Bank Description</span>
						<?php echo my_first_editor(); ?>
					</li>
				</ul>
			</div>
			
			
			<h2>Manor Park Branch</h2>
			<div class="card-js form-group">
				<ul>
					<li>
						<span>Add Bank Description</span>
						<?php echo my_second_editor(); ?>
					</li>
				</ul>
			</div>
			<button type="submit" id="btnsubmit">Submit</button>
			<span id="email_status"></span>
			</fieldset>
		</form>
	</div>
</div>
<script>
 jQuery('#example-form').validate({

  			submitHandler: function(form) {
  				var sagicorbank_details = jQuery('#sagicorbank_details').val();
  				var manorbank_details = jQuery('#manorbank_details').val();
                var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";

                var data = {'sagicorbank_details':sagicorbank_details,
                'manorbank_details':manorbank_details,                   
                    'action':'bank_details'};

                jQuery.ajax({
                    url: ajaxurl,     
                    data: data,
                    type : 'POST',
                    success:function(response) {       
                    jQuery( '#email_status' ).html(response);              
                    console.log(response);
                    
                    }
                }); 
  			}
});
</script>