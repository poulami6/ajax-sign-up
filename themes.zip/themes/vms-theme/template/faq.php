<?php
/**
 * Template Name: Faq
 */
get_header();
global $post; 
$content_post = get_post(get_the_ID());
$content = $content_post->post_content;
$content = apply_filters('the_content', $content);
?>

<div id="content" class="site-content">
				
	<!-- Banner -->
	<div class="banner inner-banner">
		<div class="container">
			<div class="first-image">
				<img src="<?php echo get_field('banner_image',get_the_ID()); ?>" alt="banner image">
			</div>
			<div class="page-heading">
				<div class="company-headlines">
					<h2><?php echo get_field('banner_text',get_the_ID()); ?></h2>
				</div>
			</div>
			<div class="last-image">
				<img src="<?php echo get_field('banner_inner_image',get_the_ID()); ?>" alt="banner image">
			</div>
		</div>
	</div>

<!-- Privacy Policy -->
<div class="privacy-policy">
	<div class="container">
		<h2 class="elementor-heading-title"><?php echo get_field('banner_text',get_the_ID()); ?></h2>
		<?php echo $content; ?>	
		<div id="accordion">
			<?php 
				$count = 1;
            	query_posts(array('orderby'=>'menu_order' ,'post_type'=>'faqs','order'=>'DESC'));
            	while(have_posts()){
                if(have_posts()){
                the_post(); 
                $image_url = get_the_post_thumbnail_url(get_the_ID(),'full');			                    
			?>
			<h3><?php echo $count; ?>. <?php echo get_the_title(); ?></h3>
			<div>
				<?php echo get_the_content(); ?>
			</div>
			<?php } $count++; } wp_reset_query(); ?>
		</div>
	</div>
</div>

</div>
<?php get_footer(); ?>				