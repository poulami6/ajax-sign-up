<?php
/**
 * Template Name: Pricing
 */
 get_header();   global $post; 

// Set access permissions

$page_id = get_the_ID();
$page_array = array('424','425','426','427','428','429');
 if (in_array($page_id, $page_array) && !is_user_logged_in() ) { ?>
 	<script type="text/javascript">
 		var sign_up = '<?php echo home_url('sign-in'); ?>';
 		var home = '<?php echo home_url(); ?>';
 		confirm = confirm("Please sign-in first to access this page.");
 		if(confirm == true){
 			window.location.href = sign_up;
 		}else{
 			window.location.href = home;
 		}
 	</script>
<?php } 
if(in_array($page_id, $page_array) && !current_user_can('customer') ){ ?>

	<script type="text/javascript">
 		var home = '<?php echo home_url(); ?>';
 		alert('Only customer users are allow here');
 		window.location.href = home;
 	</script>

<?php } ?>


<div id="content" class="site-content">
				
	<!-- Banner -->
	<div class="banner inner-banner">
		<div class="container">
			<div class="first-image">
				<img src="<?php echo get_field('banner_image',get_the_ID()); ?>" alt="banner image">
			</div>
			<div class="page-heading">
				<div class="company-headlines">
					<h2><?php echo get_field('banner_text',get_the_ID()); ?></h2>
				</div>
			</div>
			<div class="last-image">
				<img src="<?php echo get_field('banner_inner_image',get_the_ID()); ?>" alt="banner image">
			</div>
		</div>
	</div>

	<!-- How It Works -->
	<div class="package-pricing">
		<div class="container">
			<?php

			$content_post = get_post(get_the_ID());
			$content = $content_post->post_content;
			echo $content = apply_filters('the_content', $content);

			?>
		</div>
	</div>
 <?php get_footer(); ?>
 