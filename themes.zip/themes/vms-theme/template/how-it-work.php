<?php
/**
 * Template Name: How it work Page
 */
 get_header(); ?>

<div id="content" class="site-content">
				
	<!-- Banner -->
	<div class="banner inner-banner">
		<div class="container">
			<div class="first-image">
				<img src="<?php echo get_field('banner_image',get_the_ID()); ?>" alt="banner image">
			</div>
			<div class="page-heading">
				<div class="company-headlines">
					<h2><?php echo get_field('banner_title',get_the_ID()); ?></h2>
				</div>
			</div>
			<div class="last-image">
				<img src="<?php echo get_field('banner_inner_image',get_the_ID()); ?>" alt="banner image">
			</div>
		</div>
	</div>

	<!-- How It Works -->
	<div class="how-it-works">
		<?php // check if the repeater field has rows of data
		    $count = 0;
		    $num = 1;
		    $row = array('','second-row','third-row','fourth-row');
			if( have_rows('how_it_work') ):

			 	// loop through the rows of data
			    while ( have_rows('how_it_work') ) : the_row(); 
		?>
					<div class="row <?php echo $row[$count]; ?>">
						<div class="container">
							<div class="block text-block">
								<span><?php echo $num; ?></span>
								<div class="text">
									<?php the_sub_field('content'); ?>
								</div>
							</div>
							<div class="block image-block">
								<img src="<?php the_sub_field('image'); ?>" alt="How it work no image">
							</div>
						</div>
					</div>
		<?php 
			$count++;
			$num++;    
			    endwhile;

			else : 
		?>
				<div class="row <?php echo $row[$count]; ?>">
					<div class="container">
						<div class="block text-block">
							<p> No content found</p>
						</div>
					</div>
				</div>
		<?php endif; ?>
	</div>
 <?php get_footer(); ?>