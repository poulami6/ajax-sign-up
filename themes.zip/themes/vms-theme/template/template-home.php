<?php
/**
 * Template Name: Home Page Template
 */
 get_header(); ?>

<div id="content" class="site-content">
				
				<!-- Banner -->
				<div class="banner">
					<div class="wrap">
						<div class="container">
							<div class="text-block">
								<div class="company-headlines">
									<?php echo get_field('banner_heading',get_the_ID()); ?>
								</div>
								<?php echo get_field('banner_description',get_the_ID()); ?>
								<a href="<?php echo get_field('signup_link',get_the_ID()); ?>" class="btn">Sign Up Now</a>
							</div>
							<?php 
							$banner_image = get_field('banner_image',get_the_ID());							
							?>
							<div class="image-block">
								<img src="<?php echo $banner_image['url']; ?>" alt="">
							</div>
						</div>
					</div>
				</div>

				<!-- Virtual Post -->
				<div class="vertual-post">
					<div class="container">
						<h6 class="heading"><?php echo get_field('welcome_heading',get_the_ID()); ?></h6>
						<div class="left-block">
							<?php echo get_field('left_block',get_the_ID()); ?>
						</div>
						<div class="right-block">
							<?php echo get_field('right_block',get_the_ID()); ?>
						</div>
					</div>
				</div>

				<!-- About Us -->
				<div class="about-us">
					<div class="image-block">
						<?php
						 $about_image = get_field('about_image_block',get_the_ID());
						?>
						<video class="about-video" autoplay loop controls>
						  <source src="<?php echo get_field('about_video',get_the_ID()); ?>" type="video/mp4">
						</video>
						<img src="<?php echo $about_image['url']; ?>" alt="">
					</div>
					<div class="column">
						<div class="data">
							<h6 class="heading"><?php echo get_field('about_heading',get_the_ID()); ?></h6>
							<?php echo get_field('about_description',get_the_ID()); ?>
							<a href="<?php echo get_field('about_read_more_link',get_the_ID()); ?>" title="" class="btn">Read More</a>
						</div>
					</div>
				</div>

				<!-- Mail Service -->
				<div class="mail-service">
					<div class="container">
						<h6>Services</h6>
						<h2>Virtual Mail Services</h2>
						<ul>
							<?php if( have_rows('service',get_the_ID()) ): ?>					
					<?php
					// loop through rows (parent repeater)
					while( have_rows('service',get_the_ID()) ): the_row(); ?>
						
							<?php 
								  $image_1 = get_sub_field('image_1');
								  $image_2 = get_sub_field('image_2');
								  $image_text = get_sub_field('image_text');
							?>


							<li>
								<figure><img src="<?php echo $image_1['url']; ?>"></figure>
								<img src="<?php echo $image_2['url']; ?>" alt="">
								<h4><?php echo $image_text; ?></h4>
							</li>
							<?php
							endwhile;
							endif;
							?>							
						</ul>
					</div>
				</div>

				<!-- Advantage -->
				<div class="advantage">
					<div class="container">
						<?php echo get_field('advantage_heading',get_the_ID()); ?>
						<div class="block">
							<?php echo get_field('advantage_left_block',get_the_ID()); ?>
							<h5><a href="<?php echo get_field('advantage_sign_up_link',get_the_ID()); ?>" title="">Sign up</a> to start offering Virtual Post Solutions</h5>
						</div>
						<div class="block">
							<?php echo get_field('advantage_right_block',get_the_ID()); ?>
							<h5><a href="<?php echo get_field('advantage_subscribe_link',get_the_ID()); ?>" title="">Subscribe today</a></h5>
						</div>
					</div>
				</div>

				<!-- Free Guide -->
				<div class="free-guide">
					<div class="container">
						<?php
						$download_image = get_field('download_image',get_the_ID()); 
						$download_file  = get_field('download_link',get_the_ID());
						?>
						<figure><img src="<?php echo $download_image['url'];?>" alt=""></figure>
						<h2><?php echo get_field('download_text',get_the_ID()); ?></h2>
						<?php if($download_file) { ?>
						<a target="_blank" href="<?php echo $download_file; ?>" class="btn"><?php echo get_field('download_button_text',get_the_ID()); ?></a>
						<?php }else{ ?>
							<a  class="btn"><?php echo get_field('download_button_text',get_the_ID()); ?></a>
						<?php } ?>	
					</div>
				</div>

				
<?php get_footer(); ?>