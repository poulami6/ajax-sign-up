<?php
/**
 * Template Name: Test
 */
 get_header();  

global $wpdb,$current_user;

        $table_name = $wpdb->prefix.'threads';
        $sql = $wpdb->get_results("SELECT DISTINCT *  FROM $table_name Where `to` = 26 GROUP BY `thread_id` ORDER BY id desc LIMIT 10 OFFSET 0  ");
       
        echo "<pre>";
        print_r($sql);

        echo $wpdb->last_error;
        echo $wpdb->last_query; die;

 ?>

<div id="content" class="site-content">
				
	<!-- Banner -->
	<div class="banner inner-banner">
		<div class="container">
			<div class="first-image">
				<img src="<?php echo get_field('banner_image',get_the_ID()); ?>" alt="banner image">
			</div>
			<div class="page-heading">
				<div class="company-headlines">
					<h2><?php echo get_field('banner_title',get_the_ID()); ?></h2>
				</div>
			</div>
			<div class="last-image">
				<img src="<?php echo get_field('banner_inner_image',get_the_ID()); ?>" alt="banner image">
			</div>
		</div>
	</div>

	<!-- How It Works -->
	<div class="how-it-works">
		<h1>Demo</h1>
		<?php global $post; 

		$content_post = get_post(get_the_ID());
$content = $content_post->post_content;
echo $content = apply_filters('the_content', $content);

		?>
	</div>
 <?php get_footer(); ?>
 