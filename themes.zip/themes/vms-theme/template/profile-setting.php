<?php
/**
 * Template Name: Profile settings 
 */
get_header('dashboard'); 
	if(!is_user_logged_in() || current_user_can( 'operator' ) || current_user_can( 'administrator' ) ){
		wp_redirect( home_url() );
	}

	global $wpdb,$post;
	$tablename 		= $wpdb->prefix.'threads';
	$user_id 		= get_current_user_id();
	$SiteUsers 		= new SiteUsers();
	$SiteUsersData 	= $SiteUsers->_get_user_data_by_id($user_id);
	$membership_name = $SiteUsersData['membership']['name'];
	$start_date 	= $SiteUsersData['membership']['start_date'];
	$enddate 		= $SiteUsersData['membership']['enddate'];
	$first_name 	= $SiteUsersData['metadata']['first_name'];
	$last_name 		= $SiteUsersData['metadata']['last_name'];
	$_phonenumber 	= $SiteUsersData['metadata']['_phonenumber'];
	$_usertype 		= $SiteUsersData['metadata']['_usertype'];
	$_countryname 	= $SiteUsersData['metadata']['_countryname'];
	$_cityname 		= $SiteUsersData['metadata']['_cityname'];
	$_streetname 	= $SiteUsersData['metadata']['_streetname'];
	$_aptno 		= $SiteUsersData['metadata']['_aptno'];
	$_businessname 	= $SiteUsersData['metadata']['_businessname'];
	$current_date   = date('Y-m-d H:m:s');
	 $days 			= dateDifference($current_date,$enddate); 


?>
 	<div class="profile-update">
			<div class="scrollable">
				<div class="upgrade-plan">
					<div class="plan-details">
						<h2>Current Plan</h2>
						<?php 

						if( $SiteUsersData['membership']['membership_id'] != ""){
						    $status = $SiteUsersData['membership']['status'];
								if($status == 'active' && $days >= 1){ ?>
								<a href="javascript:void(0);" title=""><?php echo $membership_name; ?></a>
								<h4><?php echo $days; ?> days remaining</h4>
							<?php }else{ ?>
								<a href="javascript:void(0);" title="">Expired</a>
								<h4>Please upgrade your plan</h4>
							<?php }

						}else{ ?>

							<a href="javascript:void(0);" title="">Empty</a>
							<h4>You don't have any plan</h4>
							
						<?php } ?>
						
					</div>
					<div class="upgrade">
						<a href="<?php echo home_url('pricing'); ?>" title="">Upgrade Now</a>
					</div>
				</div>
				<div class="upgrade-profile">
					<h4>Profile name and credentials</h4>
					<form action="" method="" accept-charset="">
						<div class="aside">
							<div class="block full">
								<label for="">First name</label>
								<input type="text" name="" value="<?php echo $first_name; ?>" id="fname">
							</div>
							<div class="block full">
								<label for="">Last name</label>
								<input type="text" name="" value="<?php echo $last_name; ?>" id="lname">
							</div>
							<div class="block full">
								<label for="">Your email</label>
								<input type="email" name="" disabled value="<?php echo $user_email; ?>" id="email">
							</div>
						</div>
						<div class="aside">
							<label for="">Change your default address</label>
							<div class="block width60 gap-right">
								<input type="text" name="" value="<?php echo $_streetname; ?>" id="street">
								<span>Street</span>
							</div>
							<div class="block width38">
								<input type="text" name="" value="<?php echo $_aptno; ?>" id="aptno">
								<span>Apt/Suite</span>
							</div>
							<div class="block width38 gap-right">
								<input type="text" name="" value="<?php echo $_cityname; ?>" id="city">
								<span>City/Town</span>
							</div>
							<div class="block width38 gap-right">
								<input type="text" name="" value="<?php echo $_countryname; ?>" id="country">
								<span>Country</span>
							</div>

							<div class="block width38 gap-right">
								<input type="text" name="" value="<?php echo $_phonenumber; ?>" id="phone">
								<span>Phone</span>
							</div>
						</div>
					</form>
				</div>
				<div class="upgrade-profile">
					<h4>Your password</h4>
					<form action="" method="" accept-charset="">
						<div class="block width32 gap-right">
							<label for="">Old password</label>
							<input type="password" name="" id="oldpsw">
						</div>
						<div class="block width32 gap-right">
							<label for="">New password</label>
							<input type="password" name="" id="newpsw">
						</div>
						<div class="block width32">
							<label for="">Retype password</label>
							<input type="password" name="" id="confpsw">
						</div>
					</form>
				</div>
				<div class="btn-group">
					<button type="button" id="update_profile">Update info</button>
				</div>
			</div>
		</div>
	</div>
<?php get_footer('dashboard'); ?>