<?php 
/**
 *Template Name: Sign-in page
 *
 */ 
	get_header(); 
	if(is_user_logged_in()){
		wp_redirect( home_url() );
	}
?>

<div id="content" class="site-content">
				
<!-- Banner -->
<div class="banner inner-banner">
	<div class="container">
		<div class="first-image">
			<img src="<?php echo get_field('banner_image',get_the_ID()); ?>" alt="">
		</div>
		<div class="page-heading">
			<div class="company-headlines">
				<h2><?php echo get_field('banner_text',get_the_ID()); ?></h2>
			</div>
		</div>
		<div class="last-image">
			<img src="<?php echo get_field('banner_inner_image',get_the_ID()); ?>" alt="">
		</div>
	</div>
</div>

<!-- Fingertips -->
<div class="login-outer">
	<div class="container">
		<div class="contact-from-inr">
			<ul class="contact-from">
				<span class="error" style="color: #ffff; background-color: #FF0000;border-radius: 15px;padding: 4px; display: none;"></span>
				<li>
					<input class="text-fild" type="text" name="email" id="email" placeholder="Email address" value="" />
				</li>
				<li>
					<input class="text-fild" type="password" name="psw" id="psw" placeholder="Password" value="" />
				</li>
				<li class="control">
					<input class="checkbox-fild" type="checkbox" value="" name="rem" id="rem" />
					<label>Remember me</label>
					<a href="<?php echo get_site_url().'/forgot-password'; ?>" class="forgot-pass">Forgot password?</a>
				</li>
				<li>
					<input class="submit" type="button" id="login" value="Log In" />
				</li>
				<li class="link">
					<label>Not a member yet? </label>
					<a href="<?php echo get_site_url().'/sign-up'; ?>">Sign up</a>
				</li>
			</ul>
		</div>	
	</div>
</div>

 <?php get_footer(); ?>