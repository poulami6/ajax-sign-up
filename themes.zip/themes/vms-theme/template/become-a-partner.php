<?php
/**
 * Template Name: Become a partener Page
 */
 get_header(); ?>

 <div id="content" class="site-content">
				
	<!-- Banner -->
	<div class="banner inner-banner">
		<div class="container">
			<div class="first-image">
				<img src="<?php echo get_field('banner_image',get_the_ID()); ?>" alt="">
			</div>
			<div class="page-heading">
				<div class="company-headlines">
					<h2><?php echo get_field('banner_text',get_the_ID()); ?></h2>
				</div>
			</div>
			<div class="last-image">
				<img src="<?php echo get_field('banner_inner_image',get_the_ID()); ?>" alt="">
			</div>
		</div>
	</div>

	<!-- Fingertips -->
	<div class="fingertips">
		<div class="container">
			<h4><?php echo get_field('benefits_include_top_tagline',get_the_ID()); ?></h4>
			<div class="block">
				<h4><?php echo get_field('benefits_include_title',get_the_ID()); ?></h4>
				<?php echo get_field('benefits_include_content',get_the_ID()); ?>
			</div>
			<div class="block">
				<h4><?php echo get_field('our_advantage_title',get_the_ID()); ?></h4>
				<?php echo get_field('our_advantage_content',get_the_ID()); ?>
			</div>
		</div>
	</div>

	<!-- Process -->
	<div class="Process">
		<div class="container">
			<div class="aside">
				<h6 class="heading">heading</h6>
				<h2>Process</h2>
			</div>
			<?php // check if the repeater field has rows of data
			    $num = 1;
			   if( have_rows('process') ):

				 	// loop through the rows of data
				    while ( have_rows('process') ) : the_row(); 
			?>
					<div class="aside">
						<span>0<?php echo $num; ?></span>
						<img src="<?php the_sub_field('image'); ?>" alt="No image">
						<div class="text">
							<h2><?php the_sub_field('content'); ?></h2>
						</div>
					</div>
			<?php 
				$num++;    
				    endwhile;

				else : 
			?>
					<div class="aside">
						<p>No data found.</p>
					</div>
			<?php endif; ?>
			<div class="mail-us">
				<?php echo get_field('content',get_the_ID()); ?>
			</div>
		</div>
	</div>
 <?php get_footer(); ?>