<?php
/**
 * Template Name: Dashboard Page
 */
 get_header('dashboard'); 
 	if(!is_user_logged_in() || current_user_can( 'operator' ) || current_user_can( 'administrator' ) ){
		wp_redirect( home_url() );
	}

	// Get user data
	global $wpdb;
    $user_id 		= get_current_user_id();
	$SiteUsers 		= new SiteUsers();
	$SiteUsersData 	= $SiteUsers->_get_user_data_by_id($user_id);

	// Get Threads
	$tablename 		= $wpdb->prefix.'threads';
    $sql 			= "SELECT DISTINCT *  FROM `$tablename` WHERE `to` = ".$user_id." GROUP BY `thread_id` ORDER BY id DESC ";
	$specific_details = $wpdb->get_results($sql);
	$unread_thread 	= $wpdb->get_var( "SELECT count(*) FROM `$tablename` WHERE `to` = ".$user_id." AND `unread` = 0 " );
?>
	<!-- Main Content -->
		<div class="chat-list">
			<ul>
				<?php if (!empty($specific_details)){ ?>
					<?php foreach ($specific_details as $key => $value): 
						$thread_date = strtotime($value->thread_created);
						$thread_ended_date = strtotime($value->thread_ended_date); 
						$current_date = date('Y-m-d H:m:s A');
						$days = dateDifference($value->thread_created,$current_date);
						if($thread_ended_date == 0){
					?>
						<li> 
							<a href="javascript:void(0);" data-id="<?php echo $value->id; ?>" data-thread_id="<?php echo $value->thread_id; ?>" class="<?php if($days > 30) { ?>exceed30days<?php }else{?>threadlist<?php }?>">
								<span class="data"><strong><?php echo $value->thread_title; ?></strong><?php echo wp_trim_words($value->thread_comment,'10'); ?></span>
								<span class="time"><?php echo date('H:m A',$thread_date); ?></span>
							</a>
						</li>

					<?php } endforeach ?>
				<?php }else{  ?>
						<span class="data">NO RECORD FOUND.</span>
				<?php } ?>	
			</ul>
		</div>
		<div class="chatboard">
			<a href="javascript:void(0)" class="exit-chat"><span>x</span></a>
			<div class="inner-chat">
			</div>
			<?php if (!empty($specific_details)){ ?>
			<div class="chat-footer">
				<textarea name="" id="reply_content"></textarea>
				<button type="button" id="reply">Reply</button>
			</div>
		<?php } ?>
		</div>
	</div>
<?php if (!empty($specific_details)){ ?>
<script type="text/javascript">
	jQuery(document).ready(function($){
		$(".chat-list ul li:first-child a").click();
	});
</script>
<?php } ?>	
<?php get_footer('dashboard'); ?>