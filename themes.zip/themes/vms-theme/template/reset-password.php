<?php 
/**
 *Template Name: Reset password
 *
 */ 
 get_header(); 
// echo __string_crypt(2,'e');
$link_id = $_GET['linkid'];
if (isset($link_id) && !empty($link_id)) {
	$user_id = __string_crypt($link_id,'d');
}

 ?>
<div id="content" class="site-content">
				
<!-- Banner -->
<div class="banner inner-banner">
	<div class="container">
		<div class="first-image">
			<img src="<?php echo get_field('banner_image',get_the_ID()); ?>" alt="">
		</div>
		<div class="page-heading">
			<div class="company-headlines">
				<h2><?php echo get_field('banner_text',get_the_ID()); ?></h2>
			</div>
		</div>
		<div class="last-image">
			<img src="<?php echo get_field('banner_inner_image',get_the_ID()); ?>" alt="">
		</div>
	</div>
</div>

<!-- Fingertips -->
<div class="login-outer">
	<div class="container">
		<div class="contact-from-inr">
			<ul class="contact-from">
				<span class="error" style="color: #ffff; background-color: #FF0000;border-radius: 15px;padding: 4px; display: none;"></span>
				<span class="succ" style="color: #f1f6f1; background-color:green;border-radius: 15px;padding: 4px; display: none;"></span>
				<li>
					<input type="hidden" id="user_id" value="<?php echo $user_id; ?>">
					<input class="text-fild" type="password" id="reset_psw" placeholder="Password" />
				</li>
				<li>
					<input class="text-fild" type="password" id="reset_cpsw" placeholder="Confirm password" />
				</li>
				<li>
					<input class="submit" type="button" id="confirm" value="Update" />
				</li>
				<li class="link">
					<label>Not a member yet? </label>
					<a href="<?php echo get_site_url().'/sign-up'; ?>">Sign up</a>
				</li>
			</ul>
		</div>	
	</div>
</div>
 <?php get_footer(); ?>