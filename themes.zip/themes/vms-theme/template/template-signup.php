<?php
/*
* Template Name: Sign Up Page
*/
get_header();
?>

<div id="content" class="site-content">
<!-- Banner -->
	<div class="banner inner-banner">
		<div class="container">
			<div class="first-image">
				<img src="<?php echo get_field('banner_image'); ?>" alt="<?php echo get_field('banner_image'); ?>">
			</div>
			<div class="page-heading">
				<div class="company-headlines">
					<h2><?php echo get_field('banner_title'); ?></h2>
				</div>
			</div>
			<div class="last-image">
				<img src="<?php echo get_field('banner_inner_image'); ?>" alt="<?php echo get_field('banner_inner_image'); ?>">
			</div>
		</div>
	</div>

	<!-- Fingertips -->
	<div class="login-outer">
		<div class="container">
			<div class="contact-from-inr">
				<ul class="contact-from">
					<li class="control radiobox">
						<input type="radio" name="user_type" data-id="partner" class="user_type" value="operator" checked> Become a Partner<br>
						<input type="radio" name="user_type" data-id="customer" class="user_type" value="customer"> Customer
					</li>
				</ul>

				<div class="partner commondiv">
				<form class="user-form" id="signup_partnet" action="" method="post">
				<ul class="contact-from">
					<li>
						<input name="business_name" id="business_name" class="text-fild" type="text" placeholder="Business name" />
					</li>
					<li>
						<input name="first_name" id="first_name" class="text-fild" type="text" placeholder="First name" />
					</li>
					<li>
						<input name="last_name" id="last_name" class="text-fild" type="text" placeholder="Last name" />
					</li>
					<li class="filds">
						<p>Address</p>
						<input name="apt_no" id="apt_no" class="text-fild" type="text" placeholder="Apt no" />
					</li>
					<li>
						<input name="street_name" id="street_name" class="text-fild" type="text" placeholder="Street address" />
					</li>
					<li>
						<input name="city_name" id="city_name" class="text-fild" type="text" placeholder="City/Town" />
					</li>					
					<li>
						<input name="country_name" id="country_name" class="text-fild" type="text" placeholder="Country" />
					</li>
					
					<li>
						<input name="phone_number" id="phone_number" class="text-fild" type="text" placeholder="Phone Number/s" />
					</li>
					<li>
						<input name="user_password" id="user_password" class="text-fild" type="password" placeholder="Password" />
					</li>
					<li>
						<input name="email_address" id="email_address" class="text-fild" type="text" placeholder="Email address" />
					</li>
					<li class="massage-show">
						<input name="email_confirm" id="email_confirm" class="text-fild" type="text" onblur="confirmEmail()" placeholder="Confirm email address" />
						<p>(By submission you consent to our Terms & Conditions and Privacy Policy.)</p>
					</li>					
					<li>
						<input class="submit" type="submit" value="Submit" />
					</li>
				</ul>
				</form>
				</div>

				<div class="customer commondiv" style="display: none;">
				<form name="custform" class="user-form" id="signup_customer" action="" method="post">
					<ul class="contact-from">
						<li>
							<input name="cust_first_name" id="cust_first_name" class="text-fild" type="text" placeholder="First name" />
						</li>
						<li>
							<input name="cust_last_name" id="cust_last_name" class="text-fild" type="text" placeholder="Last name" />
						</li>
						<li>
							<input name="cust_password" id="cust_password"  class="text-fild" type="password" placeholder="Password" />
						</li>
						<li>
							<input name="cust_email_address" id="cust_email_address" class="text-fild" type="text" placeholder="Email address" />
						</li>
						<li>
							<input name="cust_confirm_email" id="cust_confirm_email" class="text-fild" type="text" placeholder="Confirm email address" onblur="confirmEmail_customer()"/>
						</li>
						<li>
							<input name="cust_company_name" id="cust_company_name" class="text-fild" type="text" placeholder="Company name (optional)" />
						</li>
						<li>
							<input name="cust_phone_number" id="cust_phone_number" class="text-fild" type="text" placeholder="Phone number" />
						</li>
						<li class="filds">
							<p>Address</p>
							<input name="cust_apt_no" id="cust_apt_no" class="text-fild" type="text" placeholder="Apt no" />
						</li>
						<li>
							<input name="cust_street_address" id="cust_street_address" class="text-fild" type="text" placeholder="Street address" />
						</li>
						<li>
							<input name="cust_town" id="cust_town" class="text-fild" type="text" placeholder="Town" />
						</li>						
						<li>
							<input name="cust_country" id="cust_country" class="text-fild" type="text" placeholder="Country" />
						</li>
						<li>
							<input class="submit" type="submit" value="Submit" />
						</li>
					</ul>
				</form>
				</div>
				<span id="email_status"></span>
			</div>	
		</div>
	</div>
</div>
<script type="text/javascript">
	jQuery('.user_type').change(function (event) {
	var id = jQuery(this).data('id');
	jQuery(".commondiv").hide();
	jQuery("."+id).show();
	
	});
</script>
<!-- <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.js"></script> -->
<script type="text/javascript">
	function confirmEmail() {
			var email = document.getElementById("email_address").value
			var confemail = document.getElementById("email_confirm").value
			if(email != confemail) {
			alert('Email Not Matching!');
			}
		}
	function confirmEmail_customer() {
			var cust_email = document.getElementById("cust_email_address").value
			var cust_confemail = document.getElementById("cust_confirm_email").value
			if(cust_email != cust_confemail) {
			alert('Email Not Matching!');
			}
		}	

	jQuery.validator.addMethod("phone_number", function(phone_number, element) {
    	    phone_number = phone_number.replace(/\s+/g, "");
    	    return this.optional(element) || phone_number.length > 9 && 
    	    phone_number.match(/^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/);
    	}, "<br />Please specify a valid phone number");
	
    jQuery.validator.addMethod("cust_phone_number", function(phone_number, element) {
    	    phone_number = phone_number.replace(/\s+/g, "");
    	    return this.optional(element) || phone_number.length > 9 && 
    	    phone_number.match(/^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/);
    	}, "<br />Please specify a valid phone number");	

	jQuery(document).ready(function(){	

	jQuery('#signup_partnet').validate({
		
		rules : {					  
					business_name:{
					      required: true
					  },
					first_name:{
						required: true
					}, 
					last_name:{
					      required: true
					  }, 
					apt_no:{
						required: true
					},
					street_name:{
					      required: true
					  }, 
					city_name:{
						required: true
					},  					
					country_name:{
						required: true
					},		
					phone_number:{
					    required: true,
					    phone_number:true
					    // phoneUS: true
					  },
					user_password:{
						required: true
					},
					email_address:{
						required: true,
						email: true
					  },
					email_confirm:{
						required: true,
						email: true
					},					
					user_type:{
						required: true
					}			
			},
				messages: {
					business_name: "Please enter business name",
					first_name: "Please enter your first name",
					last_name: "Please enter your last name",
					apt_no: "Please enter your apt no",
					street_name: "Please enter street name",
					city_name: "Please enter city name",
					country_name: "Please enter country name",
					phone_number: "Please enter valid phone number",
					user_password: "Please enter your password",
					email_address: {
						required: "Please enter your email address",
						email: "Please enter a valid email address"
					},
					email_confirm: {
						required: "Please enter confirm email address",
						email: "Please enter confirm email address"
					}					
				},

				submitHandler: function(form) {
			    	var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
			    	var business_name = jQuery('#business_name').val();
			    	var first_name = jQuery('#first_name').val();
			    	var last_name = jQuery('#last_name').val();
			    	var apt_no = jQuery('#apt_no').val();
			    	var street_name = jQuery('#street_name').val();
			    	var city_name = jQuery('#city_name').val();
			    	var country_name = jQuery('#country_name').val();
			    	var phone_number = jQuery('#phone_number').val();
			    	var user_password = jQuery('#user_password').val();
			    	var email_address = jQuery('#email_address').val();			    	
			    	var user_type = jQuery( 'input[name=user_type]:checked' ).val();
			    	$('.main-loader').show();
			    	var data = {'business_name':business_name, 
			    				'first_name':first_name, 
			    				'last_name':last_name, 
			    				'apt_no':apt_no,
			    				'street_name':street_name,
			    				'city_name':city_name,
			    				'country_name':country_name,
			    				'phone_number':phone_number,
			    				'user_password':user_password,
			    				'email_address':email_address,			    				
			    				'user_type':user_type,
			    				'action':'partner_submit_data'};
			    	$.ajax({
						url: ajaxurl,     
						data: data,
						type : 'POST',          
						success:function(response) { 
						$('.main-loader').hide();
						$( '#email_status' ).html(response);
						$("#signup_partnet")[0].reset();
						//console.log(response);	
							if(response=="OK") 
								{
								return true; 
								}
							else
								{
								return false;								
								}						 					
						}
					});
			    }
				
			});	

	jQuery('#signup_customer').validate({
		rules : {					  
				cust_first_name:{
				    required: true
				},
				cust_last_name:{
					required: true
				}, 
				cust_password:{
				    required: true
				},
				cust_email_address:{
					required: true,
					email: true
				},
				cust_confirm_email:{
					required: true,
					email: true
				},	 
				cust_phone_number:{
				    required: true,
				    cust_phone_number:true
				}, 
				cust_apt_no:{
					required: true,
				},  					
				cust_street_address:{
					required: true
				},		
				cust_town:{
				    required: true
				},
				cust_country:{
				    required: true
				}
		},
			messages: {
				cust_first_name: "Please enter your first name",
				cust_last_name: "Please enter your last name",
				cust_password: "Please enter your password",
				cust_email_address: {
					required: "Please enter your email address",
					email: "Please enter a valid email address"
				},
				cust_confirm_email: {
					required: "Please enter confirm email address",
					email: "Please enter confirm email address"
				},
				cust_phone_number: "Please enter valid phone number",
				cust_apt_no: "Please enter Apt no",
				cust_street_address: "Please enter street name",
				cust_town: "Please enter town name",
				cust_country: "Please enter country",					
			},

			submitHandler: function(form) {
		    	var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
		    	var cust_first_name = jQuery('#cust_first_name').val();
		    	var cust_last_name = jQuery('#cust_last_name').val();
		    	var cust_password = jQuery('#cust_password').val();
		    	var cust_email_address = jQuery('#cust_email_address').val();
		    	var cust_company_name = jQuery('#cust_company_name').val();
		    	var cust_phone_number = jQuery('#cust_phone_number').val();
		    	var cust_apt_no = jQuery('#cust_apt_no').val();
		    	var cust_street_address = jQuery('#cust_street_address').val();
		    	var cust_town = jQuery('#cust_town').val();	
		    	var cust_country = jQuery('#cust_country').val();		    	
		    	var user_type = jQuery( 'input[name=user_type]:checked' ).val();
		    	$('.main-loader').show();
		    	var data = {'cust_first_name':cust_first_name, 
		    				'cust_last_name':cust_last_name, 
		    				'cust_password':cust_password, 
		    				'cust_email_address':cust_email_address,
		    				'cust_company_name':cust_company_name,
		    				'cust_phone_number':cust_phone_number,
		    				'cust_apt_no':cust_apt_no,
		    				'cust_street_address':cust_street_address,
		    				'cust_town':cust_town,	
		    				'cust_country':cust_country,		    				
		    				'user_type':user_type,
		    				'action':'customer_submit_data'};
		    	$.ajax({
					url: ajaxurl,     
					data: data,
					type : 'POST',          
					success:function(response) { 
					$('.main-loader').hide();	
					$( '#email_status' ).html(response);
					$("#signup_customer")[0].reset();
					//console.log(response);	
						if(response=="OK") 
							{
							return true; 
							}
						else
							{
							return false;								
							}						 					
					}
				});
		    }
	});
});
</script>
<?php get_footer();