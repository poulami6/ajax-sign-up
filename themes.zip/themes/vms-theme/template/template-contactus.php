<?php
/*
* Template Name: Contact Us Page
*/
get_header();
?>
<div id="content" class="site-content">
	<!-- Banner -->
	<div class="banner inner-banner">
		<div class="container">
			<div class="first-image">
				<img src="<?php echo get_field('banner_image'); ?>" alt="<?php echo get_field('banner_image'); ?>">
			</div>
			<div class="page-heading">
				<div class="company-headlines">
					<h2><?php echo get_field('banner_title'); ?></h2>
				</div>
			</div>
			<div class="last-image">
				<img src="<?php echo get_field('banner_inner_image'); ?>" alt="<?php echo get_field('banner_inner_image'); ?>">
			</div>
		</div>
	</div>

	<!-- Fingertips -->
	<div class="contact-us">
		<div class="container">
			<?php $page_content = get_post(get_the_ID()); 
				$content = $page_content->post_content;
				echo $content;
			?>
		</div>
	</div>

	<!-- contact-from -->
	<div class="contact-from-outer">
		<div class="container">
			<h2><?php echo get_field('contact_heading'); ?></h2>
			<div class="contact-from-inr">
				<?php echo get_field('contact_form'); ?>
			</div>						
		</div>
	</div>

	<!-- Map -->
	<div class="map-outer">
		<div class="map-inner">
			<div class="container">
				<div class="map-details">
					<h3><?php echo get_field('location_heading'); ?></h3>
					<ul>
						<li class="location">
							<h4><?php echo get_field('address_heading'); ?>: </h4>
							<p><?php echo get_field('add_address'); ?></p>
						</li>
						<li class="email">
							<h4><?php echo get_field('email_heading'); ?> : </h4>
							<p><a href="mailto:<?php echo get_field('add_email'); ?>"><?php echo get_field('add_email'); ?></a></p>
						</li>
						<li class="phone">
							<h4><?php echo get_field('phone_heading'); ?> : </h4>
							<p><a href="tel:<?php echo get_field('add_phone'); ?>"><?php echo get_field('add_phone'); ?></a></p>
						</li>
					</ul>
				</div>
			</div>
			<?php echo get_field('contact_map'); ?>
		</div>
	</div>
</div>
<?php get_footer();