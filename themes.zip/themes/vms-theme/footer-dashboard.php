
	<!-- Footer -->
	<footer class="site-footer">
		<?php echo get_field('copyright_text','option'); ?>
	</footer>
<div class="main-loader" style="display: none;">
    <div class="loader-inner" >
    <h1>Loading...</h1>
    </div>
</div>
	<!-- Jquery Library -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/jquery-2.2.4.js"></script>
	<!-- CUSTOM SCROLLBER PLUGIN -->
	<script src="<?php echo get_template_directory_uri() ?>/js/mCustomScrollber.js"></script>
	<!-- Custom jquery -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/dashboard.js"></script>
	<?php wp_footer(); ?>
</body>
</html>