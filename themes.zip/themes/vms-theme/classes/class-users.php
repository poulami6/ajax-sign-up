<?php
//====== All Users functions here ======// 
class SiteUsers{

	 public $admin;
	 public $operator;
	 public $customer;
	 public $user_id;

	function __construct(){
		$this->admin = 'administrator';
		$this->operator = 'operator';
		$this->customer = 'customer';
		$this->user_id = get_current_user_id();
	}
	// User role by user id
	public static function _get_role($user_id){
		if($user_id > 0 ){
			$get_userdata = get_userdata( $user_id );
			$role = implode(', ', $get_userdata->roles);
			return $role;
		}else{
			return false;
		}
	}

	public static function _get_customer_users_email(){
		$user_email_data = array();
		$args = array(
			'role'         => 'customer'
		);
		$userData = get_users( $args );
		if($userData){
			foreach ($userData as $key => $value) {
				$user_email = array('value' => $value->data->user_email,'label' => $value->data->user_email,'data-id' => '1');
				$user_email_data[] = $user_email;
			}
		}else{
			$user_email_data = '';
		}
		
		return $user_email_data;

	}

	// Get user data by user id
	public static function _get_user_data_by_id($user_id){

		global $wpdb;
		$membership_table   = $wpdb->prefix.'pmpro_memberships_users';

		$userdata 			= get_user_by('ID',$user_id);
		$user_login 		= $userdata->data->user_login;
		$user_nicename 		= $userdata->data->user_nicename;
		$user_email 		= $userdata->data->user_email;
		$user_registered	= $userdata->data->user_registered;
		$display_name 		= $userdata->data->display_name;
		$role 				= $userdata->roles[0];
		$user_registered    = $userdata->data->user_registered;
		$avatar_url         = get_avatar_url($user_id);

		// User Billing meta data
		$billing_first_name    	= get_user_meta( $user_id, 'billing_first_name', true );
		$billing_last_name     	= get_user_meta( $user_id, 'billing_last_name', true );
		$billing_company    	= get_user_meta( $user_id, 'billing_company', true );
		$billing_address_1    	= get_user_meta( $user_id, 'billing_address_1', true );
		$billing_address_2    	= get_user_meta( $user_id, 'billing_address_2', true );
		$billing_city    		= get_user_meta( $user_id, 'billing_city', true );
		$billing_postcode    	= get_user_meta( $user_id, 'billing_postcode', true );
		$billing_country    	= get_user_meta( $user_id, 'billing_country', true );
		$billing_state    		= get_user_meta( $user_id, 'billing_state', true );
		$billing_phone    		= get_user_meta( $user_id, 'billing_phone', true );
		$billing_email    		= get_user_meta( $user_id, 'billing_email', true );
		$billingArray 			 = array(
			'billing_first_name' => $billing_first_name,
			'billing_last_name'  => $billing_last_name,
			'billing_company'    => $billing_company,
			'billing_address_1'  => $billing_address_1,
			'billing_address_2'  => $billing_address_2,
			'billing_city'       => $billing_city,
			'billing_postcode'   => $billing_postcode,
			'billing_country'    => $billing_country,
			'billing_state'      => $billing_state,
			'billing_phone'      => $billing_phone,
			'billing_email'      => $billing_email,
		);

		// User Shiping meta data
		$shipping_first_name    = get_user_meta( $user_id, 'shipping_first_name', true );
		$shipping_last_name    	= get_user_meta( $user_id, 'shipping_last_name', true );
		$shipping_company    	= get_user_meta( $user_id, 'shipping_company', true );
		$shipping_address_1    	= get_user_meta( $user_id, 'shipping_address_1', true );
		$shipping_address_2    	= get_user_meta( $user_id, 'shipping_address_2', true );
		$shipping_city    		= get_user_meta( $user_id, 'shipping_city', true );
		$shipping_postcode    	= get_user_meta( $user_id, 'shipping_postcode', true );
		$shipping_country    	= get_user_meta( $user_id, 'shipping_country', true );
		$shipping_state    		= get_user_meta( $user_id, 'shipping_state', true );
		$shipping_phone    		= get_user_meta( $user_id, 'shipping_phone', true );
		$shipping_email    		= get_user_meta( $user_id, 'shipping_email', true );
		$shippingArray 			 = array(
			'shipping_first_name' => $shipping_first_name,
			'shipping_last_name'  => $shipping_last_name,
			'shipping_company'    => $shipping_company,
			'shipping_address_1'  => $shipping_address_1,
			'shipping_address_2'  => $shipping_address_2,
			'shipping_city'       => $shipping_city,
			'shipping_postcode'   => $shipping_postcode,
			'shipping_country'    => $shipping_country,
			'shipping_state'      => $shipping_state,
			'shipping_phone'      => $shipping_phone,
			'shipping_email'      => $shipping_email,
		);

		// Membership details
		$sql = $wpdb->get_results( "SELECT * FROM $membership_table WHERE user_id = '".$user_id."' AND status = 'active' " );
		$membership_id = $sql[0]->membership_id;
		$status		   = $sql[0]->status;
		$startdate     = $sql[0]->startdate;
		$enddate       = $sql[0]->enddate;

		$menbership 			  = self::_get_membership_data($membership_id);
		$menbership['start_date'] = $startdate;
		$menbership['enddate'] 	  = $enddate;
		$menbership['status']     = $status;

		//Meta data
		$nickname 				  = get_user_meta($user_id,'nickname',true);
		$first_name 			  = get_user_meta($user_id,'first_name',true);
		$last_name 				  = get_user_meta($user_id,'last_name',true);
		$_businessname 			  = get_user_meta($user_id,'_businessname',true);
		$_aptno 				  = get_user_meta($user_id,'_aptno',true);
		$_streetname 			  = get_user_meta($user_id,'_streetname',true);
		$_cityname 				  = get_user_meta($user_id,'_cityname',true);
		$_countryname 			  = get_user_meta($user_id,'_countryname',true);
		$_usertype 				  = get_user_meta($user_id,'_usertype',true);
		$_phonenumber 			  = get_user_meta($user_id,'_phonenumber',true);
		$metadata = array(
			'nickname' 		    => $nickname,
			'first_name' 		=> $first_name,
			'last_name' 		=> $last_name,
			'_businessname' 	=> $_businessname,
			'_aptno' 			=> $_aptno,
			'_streetname' 		=> $_streetname,
			'_cityname' 		=> $_cityname,
			'_countryname' 		=> $_countryname,
			'_usertype' 		=> $_usertype,
			'_phonenumber' 		=> $_phonenumber,
		);

		$result = array(
			'user_login' 		=> $user_login,
			'user_nicename' 	=> $user_nicename,
			'user_email' 		=> $user_email,
			'user_registered' 	=> $user_registered,
			'display_name' 		=> $display_name,
			'role' 				=> $role,
			'avatar_url'        => $avatar_url,
			'user_registered'   => $user_registered,
			'billing_details'   => $billingArray,
			'shipping_details'  => $shippingArray,
			'membership'        => $menbership,
			'metadata'          => $metadata 

		);

        return $result;
	}


	public static function _get_membership_data($membership_id){

		global $wpdb;
		$membership_table   = $wpdb->prefix.'pmpro_membership_levels';
		$sql 				= $wpdb->get_results( "SELECT * FROM $membership_table WHERE id = '".$membership_id."' " );
		$name 				= $sql[0]->name;
		$description 		= $sql[0]->description;
		$billing_amount 	= $sql[0]->billing_amount;
		$cycle_number 		= $sql[0]->cycle_number;
		$cycle_period 		= $sql[0]->cycle_period;
		$billing_limit 		= $sql[0]->billing_limit;
		$expiration_number 	= $sql[0]->expiration_number;
		$expiration_period 	= $sql[0]->expiration_period;

		$return = array(
			'membership_id'     => $membership_id,
			'name' 				=> $name,
			'description' 		=> $description,
			'billing_amount' 	=> $billing_amount,
			'cycle_number' 		=> $cycle_number,
			'cycle_period' 		=> $cycle_period,
			'billing_limit' 	=> $billing_limit,
			'expiration_number' => $expiration_number,
			'expiration_period' => $expiration_period,
		);

		return $return;

	}	

}

/*$SiteUsers = new SiteUsers();
$SiteUsersData = $SiteUsers->_get_user_data_by_id(26);
echo "<pre>"; print_r($SiteUsersData); die;*/