<!-- Testimonials -->
				<div class="testimonials">
					<div class="container">
						<h6>Testimonials</h6>
						<h2>Happy Customers</h2>
						<div class="owl-carousel owl-theme single-item-slide">
							<?php 
			                	query_posts(array('orderby'=>'menu_order' ,'post_type'=>'testimonial','order'=>'ASC'));
			                	while(have_posts()){
			                    if(have_posts()){
			                    the_post(); 
			                    $image_url = get_the_post_thumbnail_url(get_the_ID(),'full');			                    
                			?>
							<div class="item">
								<div class="image-block">
									<figure><img src="<?php echo $image_url; ?>" alt=""></figure>
								</div>
								<div class="text-block">
									<h3><?php echo get_the_title(); ?></h3>
									<h4><?php echo get_field('testimonial_second_heading',get_the_ID()); ?></h4>
									<?php echo get_the_content(); ?>
								</div>
							</div>
							<?php
							}}
                    		wp_reset_query(); 
							?>							
						</div>
						<div class="brand">
							<ul>
								<?php 
				                	query_posts(array('orderby'=>'menu_order' ,'post_type'=>'brand','order'=>'ASC'));
				                	while(have_posts()){
				                    if(have_posts()){
				                    the_post(); 
				                    $image_url = get_the_post_thumbnail_url(get_the_ID(),'full');			                    
                				?>
								<li><img src="<?php echo $image_url; ?>" alt=""></li>
								<?php
									}}
		                    		wp_reset_query(); 
								?>
							</ul>
						</div>
					</div>
				</div>
			</div>
<!-- Footer -->
			<footer id="colophon" class="site-footer" role="contentinfo">
				<div class="top-footer">
					<div class="container">
						<div class="block">
							<h6><?php echo get_field('footer_about_us_heading','option'); ?></h6>
							<p><?php echo get_field('footer_about_us_content','option'); ?> <a href="<?php echo get_field('footer_about_us_link','option'); ?>">MORE..</a></p>
							<ul class="social">
								<li><a target="_blank" href="<?php echo get_field('facebook_link','option'); ?>"><img src="<?php echo get_template_directory_uri() ?>/images/icon-facebook.png" alt=""></a></li>
								<li><a target="_blank" href="<?php echo get_field('instagram_link','option'); ?>"><img src="<?php echo get_template_directory_uri() ?>/images/icon-instagram.png" alt=""></a></li>
								<li><a target="_blank" href="<?php echo get_field('youtube_link','option'); ?>"><img src="<?php echo get_template_directory_uri() ?>/images/icon-youtube.png" alt=""></a></li>
							</ul>
						</div>
						<div class="block">
							<h6>Our Services</h6>							
							<?php wp_nav_menu( array( 'theme_location' => 'secondary' , 'container' => '','menu_class' => '' ) ); ?>	
						</div>
						<div class="block">
							<h6>Quick Contact</h6>
							<strong>Email :</strong>
							<a href="mailto:<?php echo get_field('quick_contact_email','option'); ?>"><?php echo get_field('quick_contact_email','option'); ?></a>
							<strong>Phone :</strong>
							<a href="tel:<?php echo get_field('quick_contact_phone','option'); ?>"><?php echo get_field('quick_contact_phone','option'); ?></a>
						</div>
					</div>
				</div>
				<div class="bottom-header">
					<div class="container">
						<?php echo get_field('copyright_text','option'); ?>
					</div>
				</div>
			</footer>
		</div>
	</div>
<div class="main-loader" style="display: none;">
    <div class="loader-inner" >
    <h1>Loading...</h1>
    </div>
</div>
	<!-- Jquery Library -->
	<!-- <script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/jquery-2.2.4.js"></script> -->
	<!-- Wordpress function.js -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/functions.js"></script>
	<!-- Owl -->
  	<script src="<?php echo get_template_directory_uri() ?>/js/owl.carousel.js"></script>
	<!-- Custom jquery -->
	<script type="text/javascript" src="<?php echo get_template_directory_uri() ?>/js/script.js"></script>
	<?php wp_footer(); ?>
</body>
</html>