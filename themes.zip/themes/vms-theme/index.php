<?php
/**
 * The main template file
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage VMS
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

		


<?php get_footer(); ?>
