$(document).ready(function(){
  toggle();
  Chattoggle();
  customscroll();
});



// Toggle Menu
function toggle() {
  $('.toggle').on('click', function(){
  $('.toggle').toggleClass('is-clicked');
    if ( $('.left-aside').hasClass('show-more') ) {
      $('.left-aside').removeClass('show-more');
      $('body').removeClass('overflow-hidden');
    }
    else {
      $('.left-aside').addClass('show-more');
      $('body').addClass('overflow-hidden');
    }
  });
}

// Toggle Menu
function Chattoggle() {
  $('.chat-list > ul > li, .exit-chat').on('click', function(){
  $('.chat-list > ul > li, .exit-chat').toggleClass('is-clicked');
    if ( $('.chatboard').hasClass('show-more') ) {
      $('.chatboard').removeClass('show-more');
      $('body').removeClass('hidden');
    }
    else {
      $('.chatboard').addClass('show-more');
      $('body').addClass('hidden');
    }
  });
}


function customscroll() {
  $(".chat-history").mCustomScrollbar({
          autoHideScrollbar:true,
  }).mCustomScrollbar("scrollTo","bottom",{scrollInertia:0});

  $(".chat-list ul, .scrollable").mCustomScrollbar({
        scrollButtons:{enable:true},
        //theme:"light-3",
        scrollbarPosition:"outside"
  });

  $('.left-aside nav ul').mCustomScrollbar({
      autoHideScrollbar:true,
  });
}