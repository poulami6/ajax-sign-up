$(document).ready(function(){
  toggleMenu();
  fixedheader();
  owlcarousal();
  accordion();
});



// Toggle Menu
function toggleMenu() {
  $('.toggleMenu').on('click', function(){
  $('.toggleMenu').toggleClass('is-clicked');
    if ( $('.main-navigation').hasClass('show-more') ) {
      $('.main-navigation').removeClass('show-more');
      $('body').removeClass('overflow-hidden');
      $('.sub-menu').removeClass('show')
    }
    else {
      $('.main-navigation').addClass('show-more');
      $('body').addClass('overflow-hidden');
      $('.sub-menu').addClass('show')
    }
  });

  /*For Dropdown*/
  $(".menu-item-has-children").click(function(){
      $(this).find(".sub-menu.show").slideToggle("fast");
  });
}


//Fixed Header
function fixedheader() {
  jQuery(window).scroll(function() {
    if(jQuery(window).scrollTop() > 250) {
    jQuery(".site-header").addClass("fixed");
    } else {
    //remove the background property so it comes transparent again (defined in your css)
    jQuery(".site-header").removeClass("fixed");
    }
  });
}


//Owl Carousla
function owlcarousal() {
  $(".single-item-slide").owlCarousel({
    loop:true,
    navigation:true,
    items:1,
    autoplay:true,
    margin:0,
    smartSpeed:4000,
    //animateOut: 'fadeOut',
    responsive:{
      0:{
      items:1,
      margin:0,
      autoplay:true,
      }
    }
  });
}

//Accordian Jquery UI
function accordion() {
  $("#accordion").accordion({
    heightStyle: "content" 
  });
}