jQuery(document).ready(function($){
	// Sign-in with ajax
  $('#login').click(function(){
      var email = $('#email').val();
      var psw = $('#psw').val();
      var rem = $('input[type="checkbox"]').prop("checked");
      
      if(email == ""){
        $('.error').text('Enter valid email address');
        $('.error').show();
        $('#email').focus();
      }else if(psw == ""){
        $('.error').text('Enter valid password');
        $('.error').show();
        $('#psw').focus();
      }else{
        $('.error').hide();
        $('.main-loader').show();
        var data = {'email':email,'psw':psw,'rem':rem,'action':'_user_sign'};
        $.ajax({
          type : "post",
          data : data,
          url : my_ajax.ajax_url,
          success: function(res){
            $('.main-loader').hide();
            if(res.login_user == true){
              window.location = res.profile_url;
            }else{
              $('.error').show();
              $('.error').text(res.msg);
            }
          }
        });
      }
    });

  //Forgot password
  $('#forgot').click(function(){
    $('.main-loader').show();
    var forgotEmail = $('#forgotEmail').val();
    var data = {'forgotEmail':forgotEmail,'action':'__email_exists_or_not'};
    $.ajax({
      type : "post",
      data : data,
      url : my_ajax.ajax_url,
      success: function(res){
        $('.main-loader').hide();
        if(res == true){
          $('.succ').text('Please check your Email box');
          $('.error').hide();
          $('.succ').show();
          $('#forgotEmail').val('');
        }else{
          $('.error').text('Please enter valid email address');
          $('.error').show();
          $('.succ').hide();
        }
      }
    });
  });

  //Reset password
  $('#confirm').click(function(){
    var reset_psw = $('#reset_psw').val();
    var reset_cpsw = $('#reset_cpsw').val();
    var user_id = $('#user_id').val();
    if(reset_psw == ""){
      $('.error').show();
      $('.error').text('Please enter your password');
    }else if(reset_cpsw == ""){
      $('.error').show();
      $('.error').text('Please confirm your password');
    }else{
      console.log(reset_psw);
      console.log('@'+reset_cpsw);
      if(reset_psw == reset_cpsw){ 
          if(user_id > 0){
            $('.error').hide();
            $('.main-loader').show();
            var data = {'reset_psw':reset_psw,'user_id':user_id,'action':'__reset_password'};
            $.ajax({
              type : "post",
              data : data,
              url : my_ajax.ajax_url,
              success: function(res){
                $('.main-loader').hide();
                if(res == 1){
                  $('.succ').text('Password is successfully updated.');
                  $('.error').hide();
                  $('.succ').show();
                }else{
                  $('.error').text('Invalid user');
                  $('.error').show();
                  $('.succ').hide();
                }
              }
            });
          }else{
            $('.error').text('Oops! Something went wrong');
            $('.error').show();
            $('.succ').hide();
          }
      }else{
        $('.error').show();
        $('.error').text('Password Mismatch.');
      }
    }  

  });  

  // Form submit on Enter key
  $("input").keypress(function(event) {
    if (event.which == 13) {
        $(".submit").trigger('click');
    }
  });

  //Front Dashboad thread details on thread click
  $('.threadlist').click(function(){
    $('.main-loader').show();
    var rowId = $(this).data('id');
    var thread_id = $(this).data('thread_id');
    var postdata = {'thread_id':thread_id,'rowId':rowId,'action':'_dashboard_threadDetails'}
    $.ajax({
      type : "post",
      data : postdata,
      url : my_ajax.ajax_url,
      success: function(res){
        $('.main-loader').hide();
        $('.inner-chat').html(res);
      }
    });
  });  

  //Front Dashboad thread details reply section
  $('#reply').click(function(){
    $content = jQuery(".chat-body");
    var customer_option = $('#customer_option option:selected').val();
    var reply_content   = $('#reply_content').val();
    var thread_id = $('.inner-chat #thread_id').val();
    var from_user_id = $('.inner-chat #from_user_id').val();
    var thread_title = $('.inner-chat #thread_title').val();
    if(customer_option == "" && reply_content == ""){
      $('#customer_option').addClass('req');
    }else if(reply_content != "" && customer_option == ""){
    //}else if(reply_content == ""){
     // $('#reply_content').focus();
     // $('#customer_option').removeClass('req');
      $('#customer_option').addClass('req');
    }else{
      $('#customer_option').removeClass('req');
      //$('#customer_option').removeClass('req');
      //$('#reply_content').removeClass('req');
      $('.main-loader').show();
      var replydata = {'thread_title':thread_title,'customer_option':customer_option,'reply_content':reply_content,'thread_id':thread_id,'from_user_id':from_user_id,'action':'_dashboard_reply_thread'}
      $.ajax({
        type : "post",
        data : replydata,
        url : my_ajax.ajax_url,
        success: function(res){
          $('.main-loader').hide();
          if(res.status == 1){
            $('.chat-history').append(res.html);
            $('#reply_content').val('');
             $('#customer_option').prop('selectedIndex',0);
            $('#reply_content').focus();
            var chat_container = $('.chat-history').height();
            $(".chat-history").animate({ scrollTop: 100000 }, 1);
          }else{
            alert('Oops ! Something went wrong try again.');
            location.reload();
          }
          
        }
      });
    }  

  });

  // Update profile settings

    $('#update_profile').click(function(){

      var newpsw = $('#newpsw').val();
      var confpsw = $('#confpsw').val();

          $('.main-loader').show();
          var old_password   = $('#oldpsw').val();
          var new_password   = $('#newpsw').val();
          var confirm_password = $('#confpsw').val();
          var _streetname    = $('#street').val();
          var _cityname      = $('#city').val();
          var _countryname   = $('#country').val();
          var _phonenumber   = $('#phone').val();
          var _aptno         = $('#aptno').val();
          var first_name     = $('#fname').val();
          var last_name      = $('#lname').val();
          var email          = $('#email').val();
          var profile_date = {
              'old_password':old_password,
              'new_password':new_password,
              'confirm_password':confirm_password,
              '_streetname':_streetname,
              '_cityname':_cityname,
              '_countryname':_countryname,
              '_phonenumber':_phonenumber,
              '_aptno':_aptno,
              'first_name':first_name,
              'last_name':last_name,
              'action':'_update_profile_settings'
            }
          $.ajax({
            type : "post",
            data : profile_date,
            url : my_ajax.ajax_url,
            success: function(res){
              $('.main-loader').hide();
              console.log(res);
              if(res.error == 200){
                alert(res.message);
                $('#newpsw').val('');
                $('#confpsw').val('');
                $('#oldpsw').val('');
              }
              if(res.error == 401){
                alert(res.message);
              }
            }
          });
    });

    // Add dashboard link on payment success page
    $('#nav-below .nav-next.alignright').html('<a href="'+my_ajax.home_url+'/dashboard" >Dashboard →</a>');

    // Exceed 30 days of thread history alert
    $('.exceed30days').click(function(){
      alert('This thread history exceed 30 days. ');
    });
  

});